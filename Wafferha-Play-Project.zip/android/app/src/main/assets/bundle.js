// Preact, MIT License
var n,l,u,i,t,o,r={},f=[],e=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;function c(e,n){for(var t in n)e[t]=n[t];return e}function s(e){var n=e.parentNode;n&&n.removeChild(e)}function a(e,n,t){var _,l,o,r=arguments,i={};for(o in n)"key"==o?_=n[o]:"ref"==o?l=n[o]:i[o]=n[o];if(arguments.length>3)for(t=[t],o=3;o<arguments.length;o++)t.push(r[o]);if(null!=t&&(i.children=t),"function"==typeof e&&null!=e.defaultProps)for(o in e.defaultProps)void 0===i[o]&&(i[o]=e.defaultProps[o]);return v(e,i,_,l,null)}function v(e,t,_,l,o){var r={type:e,props:t,key:_,ref:l,__k:null,__:null,__b:0,__e:null,__d:void 0,__c:null,__h:null,constructor:void 0,__v:null==o?++n.__v:o};return null!=n.vnode&&n.vnode(r),r}function h(){return{current:null}}function y(e){return e.children}function p(e,n){this.props=e,this.context=n}function d(e,n){if(null==n)return e.__?d(e.__,e.__.__k.indexOf(e)+1):null;for(var t;n<e.__k.length;n++)if(null!=(t=e.__k[n])&&null!=t.__e)return t.__e;return"function"==typeof e.type?d(e):null}function _(e){var n,t;if(null!=(e=e.__)&&null!=e.__c){for(e.__e=e.__c.base=null,n=0;n<e.__k.length;n++)if(null!=(t=e.__k[n])&&null!=t.__e){e.__e=e.__c.base=t.__e;break}return _(e)}}function k(e){(!e.__d&&(e.__d=!0)&&u.push(e)&&!b.__r++||t!==n.debounceRendering)&&((t=n.debounceRendering)||i)(b)}function b(){for(var e;b.__r=u.length;)e=u.sort(function(e,n){return e.__v.__b-n.__v.__b}),u=[],e.some(function(e){var n,t,l,o,r,i;e.__d&&(r=(o=(n=e).__v).__e,(i=n.__P)&&(t=[],(l=c({},o)).__v=o.__v+1,I(i,o,l,n.__n,void 0!==i.ownerSVGElement,null!=o.__h?[r]:null,t,null==r?d(o):r,o.__h),T(t,o),o.__e!=r&&_(o)))})}function m(e,n,t,_,l,o,i,u,s,c){var p,a,h,m,k,b,C,P=_&&_.__k||f,S=P.length;for(t.__k=[],p=0;p<n.length;p++)if(null!=(m=t.__k[p]=null==(m=n[p])||"boolean"==typeof m?null:"string"==typeof m||"number"==typeof m||"bigint"==typeof m?v(null,m,null,null,m):Array.isArray(m)?v(y,{children:m},null,null,null):m.__b>0?v(m.type,m.props,m.key,null,m.__v):m)){if(m.__=t,m.__b=t.__b+1,null===(h=P[p])||h&&m.key==h.key&&m.type===h.type)P[p]=void 0;else for(a=0;a<S;a++){if((h=P[a])&&m.key==h.key&&m.type===h.type){P[a]=void 0;break}h=null}I(e,m,h=h||r,l,o,i,u,s,c),k=m.__e,(a=m.ref)&&h.ref!=a&&(C||(C=[]),h.ref&&C.push(h.ref,null,m),C.push(a,m.__c||k,m)),null!=k?(null==b&&(b=k),"function"==typeof m.type&&null!=m.__k&&m.__k===h.__k?m.__d=s=g(m,s,e):s=x(e,m,h,P,k,s),c||"option"!==t.type?"function"==typeof t.type&&(t.__d=s):e.value=""):s&&h.__e==s&&s.parentNode!=e&&(s=d(h))}for(t.__e=b,p=S;p--;)null!=P[p]&&("function"==typeof t.type&&null!=P[p].__e&&P[p].__e==t.__d&&(t.__d=d(_,p+1)),L(P[p],P[p]));if(C)for(p=0;p<C.length;p++)z(C[p],C[++p],C[++p])}function g(e,n,t){var _,l;for(_=0;_<e.__k.length;_++)(l=e.__k[_])&&(l.__=e,n="function"==typeof l.type?g(l,n,t):x(t,l,l,e.__k,l.__e,n));return n}function w(e,n){return n=n||[],null==e||"boolean"==typeof e||(Array.isArray(e)?e.some(function(e){w(e,n)}):n.push(e)),n}function x(e,n,t,_,l,o){var r,i,u;if(void 0!==n.__d)r=n.__d,n.__d=void 0;else if(null==t||l!=o||null==l.parentNode)e:if(null==o||o.parentNode!==e)e.appendChild(l),r=null;else{for(i=o,u=0;(i=i.nextSibling)&&u<_.length;u+=2)if(i==l)break e;e.insertBefore(l,o),r=o}return void 0!==r?r:l.nextSibling}function A(e,n,t,_,l){var o;for(o in t)"children"===o||"key"===o||o in n||C(e,o,null,t[o],_);for(o in n)l&&"function"!=typeof n[o]||"children"===o||"key"===o||"value"===o||"checked"===o||t[o]===n[o]||C(e,o,n[o],t[o],_)}function P(n,t,_){"-"===t[0]?n.setProperty(t,_):n[t]=null==_?"":"number"!=typeof _||e.test(t)?_:_+"px"}function C(e,n,t,_,l){var o;e:if("style"===n)if("string"==typeof t)e.style.cssText=t;else{if("string"==typeof _&&(e.style.cssText=_=""),_)for(n in _)t&&n in t||P(e.style,n,"");if(t)for(n in t)_&&t[n]===_[n]||P(e.style,n,t[n])}else if("o"===n[0]&&"n"===n[1])o=n!==(n=n.replace(/Capture$/,"")),n=n.toLowerCase()in e?n.toLowerCase().slice(2):n.slice(2),e.l||(e.l={}),e.l[n+o]=t,t?_||e.addEventListener(n,o?H:$,o):e.removeEventListener(n,o?H:$,o);else if("dangerouslySetInnerHTML"!==n){if(l)n=n.replace(/xlink[H:h]/,"h").replace(/sName$/,"s");else if("href"!==n&&"list"!==n&&"form"!==n&&"tabIndex"!==n&&"download"!==n&&n in e)try{e[n]=null==t?"":t;break e}catch(e){}"function"==typeof t||(null!=t&&(!1!==t||"a"===n[0]&&"r"===n[1])?e.setAttribute(n,t):e.removeAttribute(n))}}function $(e){this.l[e.type+!1](n.event?n.event(e):e)}function H(e){this.l[e.type+!0](n.event?n.event(e):e)}function I(e,t,_,l,o,r,i,u,s){var f,a,d,h,v,k,g,b,C,x,P,S=t.type;if(void 0!==t.constructor)return null;null!=_.__h&&(s=_.__h,u=t.__e=_.__e,t.__h=null,r=[u]),(f=n.__b)&&f(t);try{e:if("function"==typeof S){if(b=t.props,C=(f=S.contextType)&&l[f.__c],x=f?C?C.props.value:f.__:l,_.__c?g=(a=t.__c=_.__c).__=a.__E:("prototype"in S&&S.prototype.render?t.__c=a=new S(b,x):(t.__c=a=new p(b,x),a.constructor=S,a.render=M),C&&C.sub(a),a.props=b,a.state||(a.state={}),a.context=x,a.__n=l,d=a.__d=!0,a.__h=[]),null==a.__s&&(a.__s=a.state),null!=S.getDerivedStateFromProps&&(a.__s==a.state&&(a.__s=c({},a.__s)),c(a.__s,S.getDerivedStateFromProps(b,a.__s))),h=a.props,v=a.state,d)null==S.getDerivedStateFromProps&&null!=a.componentWillMount&&a.componentWillMount(),null!=a.componentDidMount&&a.__h.push(a.componentDidMount);else{if(null==S.getDerivedStateFromProps&&b!==h&&null!=a.componentWillReceiveProps&&a.componentWillReceiveProps(b,x),!a.__e&&null!=a.shouldComponentUpdate&&!1===a.shouldComponentUpdate(b,a.__s,x)||t.__v===_.__v){a.props=b,a.state=a.__s,t.__v!==_.__v&&(a.__d=!1),a.__v=t,t.__e=_.__e,t.__k=_.__k,t.__k.forEach(function(e){e&&(e.__=t)}),a.__h.length&&i.push(a);break e}null!=a.componentWillUpdate&&a.componentWillUpdate(b,a.__s,x),null!=a.componentDidUpdate&&a.__h.push(function(){a.componentDidUpdate(h,v,k)})}a.context=x,a.props=b,a.state=a.__s,(f=n.__r)&&f(t),a.__d=!1,a.__v=t,a.__P=e,f=a.render(a.props,a.state,a.context),a.state=a.__s,null!=a.getChildContext&&(l=c(c({},l),a.getChildContext())),d||null==a.getSnapshotBeforeUpdate||(k=a.getSnapshotBeforeUpdate(h,v)),P=null!=f&&f.type===y&&null==f.key?f.props.children:f,m(e,Array.isArray(P)?P:[P],t,_,l,o,r,i,u,s),a.base=t.__e,t.__h=null,a.__h.length&&i.push(a),g&&(a.__E=a.__=null),a.__e=!1}else null==r&&t.__v===_.__v?(t.__k=_.__k,t.__e=_.__e):t.__e=j(_.__e,t,_,l,o,r,i,s);(f=n.diffed)&&f(t)}catch(e){t.__v=null,(s||null!=r)&&(t.__e=u,t.__h=!!s,r[r.indexOf(u)]=null),n.__e(e,t,_)}}function T(e,t){n.__c&&n.__c(t,e),e.some(function(t){try{e=t.__h,t.__h=[],e.some(function(e){e.call(t)})}catch(e){n.__e(e,t.__v)}})}function j(e,n,t,_,l,o,i,u){var c,p,a,d,h=t.props,v=n.props,y=n.type,k=0;if("svg"===y&&(l=!0),null!=o)for(;k<o.length;k++)if((c=o[k])&&(c===e||(y?c.localName==y:3==c.nodeType))){e=c,o[k]=null;break}if(null==e){if(null===y)return document.createTextNode(v);e=l?document.createElementNS("http://www.w3.org/2000/svg",y):document.createElement(y,v.is&&v),o=null,u=!1}if(null===y)h===v||u&&e.data===v||(e.data=v);else{if(o=o&&f.slice.call(e.childNodes),p=(h=t.props||r).dangerouslySetInnerHTML,a=v.dangerouslySetInnerHTML,!u){if(null!=o)for(h={},d=0;d<e.attributes.length;d++)h[e.attributes[d].name]=e.attributes[d].value;(a||p)&&(a&&(p&&a.__html==p.__html||a.__html===e.innerHTML)||(e.innerHTML=a&&a.__html||""))}if(A(e,v,h,l,u),a)n.__k=[];else if(k=n.props.children,m(e,Array.isArray(k)?k:[k],n,t,_,l&&"foreignObject"!==y,o,i,e.firstChild,u),null!=o)for(k=o.length;k--;)null!=o[k]&&s(o[k]);u||("value"in v&&void 0!==(k=v.value)&&(k!==e.value||"progress"===y&&!k)&&C(e,"value",k,h.value,!1),"checked"in v&&void 0!==(k=v.checked)&&k!==e.checked&&C(e,"checked",k,h.checked,!1))}return e}function z(e,t,_){try{"function"==typeof e?e(t):e.current=t}catch(e){n.__e(e,_)}}function L(e,t,_){var l,o,r;if(n.unmount&&n.unmount(e),(l=e.ref)&&(l.current&&l.current!==e.__e||z(l,null,t)),_||"function"==typeof e.type||(_=null!=(o=e.__e)),e.__e=e.__d=void 0,null!=(l=e.__c)){if(l.componentWillUnmount)try{l.componentWillUnmount()}catch(e){n.__e(e,t)}l.base=l.__P=null}if(l=e.__k)for(r=0;r<l.length;r++)l[r]&&L(l[r],t,_);null!=o&&s(o)}function M(e,n,t){return this.constructor(e,t)}function N(e,t,_){var l,o,i;n.__&&n.__(e,t),o=(l="function"==typeof _)?null:_&&_.__k||t.__k,i=[],I(t,e=(!l&&_||t).__k=a(y,null,[e]),o||r,r,void 0!==t.ownerSVGElement,!l&&_?[_]:o?null:t.firstChild?f.slice.call(t.childNodes):null,i,!l&&_?_:o?o.__e:t.firstChild,l),T(i,e)}function O(e,n){N(e,n,O)}function S(e,n,t){var _,l,o,r=arguments,i=c({},e.props);for(o in n)"key"==o?_=n[o]:"ref"==o?l=n[o]:i[o]=n[o];if(arguments.length>3)for(t=[t],o=3;o<arguments.length;o++)t.push(r[o]);return null!=t&&(i.children=t),v(e.type,i,_||e.key,l||e.ref,null)}function q(e,n){var t={__c:n="__cC"+o++,__:e,Consumer:function(e,n){return e.children(n)},Provider:function(e){var t,_;return this.getChildContext||(t=[],(_={})[n]=this,this.getChildContext=function(){return _},this.shouldComponentUpdate=function(e){this.props.value!==e.value&&t.some(k)},this.sub=function(e){t.push(e);var n=e.componentWillUnmount;e.componentWillUnmount=function(){t.splice(t.indexOf(e),1),n&&n.call(e)}}),e.children}};return t.Provider.__=t.Consumer.contextType=t}n={__e:function(e,n){for(var t,_,l;n=n.__;)if((t=n.__c)&&!t.__)try{if((_=t.constructor)&&null!=_.getDerivedStateFromError&&(t.setState(_.getDerivedStateFromError(e)),l=t.__d),null!=t.componentDidCatch&&(t.componentDidCatch(e),l=t.__d),l)return t.__E=t}catch(n){e=n}throw e},__v:0},l=function(e){return null!=e&&void 0===e.constructor},p.prototype.setState=function(e,n){var t;t=null!=this.__s&&this.__s!==this.state?this.__s:this.__s=c({},this.state),"function"==typeof e&&(e=e(c({},t),this.props)),e&&c(t,e),null!=e&&this.__v&&(n&&this.__h.push(n),k(this))},p.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),k(this))},p.prototype.render=y,u=[],i="function"==typeof Promise?Promise.prototype.then.bind(Promise.resolve()):setTimeout,b.__r=0,o=0;globalThis.Preact={render:N,hydrate:O,createElement:a,h:a,Fragment:y,createRef:h,isValidElement:l,Component:p,cloneElement:S,createContext:q,toChildArray:w,options:n};
(function(){
  const P = globalThis.Preact;
  let currentComponent = null;
  let hookIndex = 0;
  const oldRender = P.options.__r;
  const oldDiffed = P.options.diffed;
  const oldUnmount = P.options.unmount;
  function depsChanged(a,b){ if(a===undefined||b===undefined)return true; if(!a||!b||a.length!==b.length)return true; for(let i=0;i<a.length;i++)if(!Object.is(a[i],b[i]))return true; return false; }
  function store(){ if(!currentComponent)throw new Error('Hooks can only be called inside a component'); return currentComponent.__simpleHooks||(currentComponent.__simpleHooks=[]); }
  function scheduleEffects(c){ if(c.__simpleEffectScheduled)return; c.__simpleEffectScheduled=true; setTimeout(()=>{ c.__simpleEffectScheduled=false; const pending=c.__simplePendingEffects||[]; c.__simplePendingEffects=[]; for(const idx of pending){ const slot=c.__simpleHooks&&c.__simpleHooks[idx]; if(!slot||!slot.pending)continue; slot.pending=false; try{if(typeof slot.cleanup==='function')slot.cleanup();}catch(e){console.error(e);} try{slot.cleanup=slot.effect?slot.effect():undefined;}catch(e){console.error(e);} } },0); }
  P.options.__r=function(vnode){ if(oldRender)oldRender(vnode); currentComponent=vnode.__c; hookIndex=0; };
  P.options.diffed=function(vnode){ const c=vnode.__c; if(c&&c.__simplePendingEffects&&c.__simplePendingEffects.length)scheduleEffects(c); if(oldDiffed)oldDiffed(vnode); };
  P.options.unmount=function(vnode){ const c=vnode.__c; if(c&&c.__simpleHooks){ for(const slot of c.__simpleHooks){ if(slot&&typeof slot.cleanup==='function'){ try{slot.cleanup();}catch(e){console.error(e);} } } } if(oldUnmount)oldUnmount(vnode); };
  function useState(initial){ const c=currentComponent,hooks=store(),idx=hookIndex++; let slot=hooks[idx]; if(!slot){ slot=hooks[idx]={value:typeof initial==='function'?initial():initial}; slot.set=function(next){ const value=typeof next==='function'?next(slot.value):next; if(!Object.is(value,slot.value)){slot.value=value;c.setState({__hookTick:((c.state&&c.state.__hookTick)||0)+1});} }; } return [slot.value,slot.set]; }
  function useRef(initial){ const hooks=store(),idx=hookIndex++; return hooks[idx]||(hooks[idx]={current:initial}); }
  function useMemo(factory,deps){ const hooks=store(),idx=hookIndex++; let slot=hooks[idx]; if(!slot||depsChanged(slot.deps,deps))slot=hooks[idx]={value:factory(),deps}; return slot.value; }
  function useCallback(fn,deps){return useMemo(()=>fn,deps);}
  function useEffect(effect,deps){ const c=currentComponent,hooks=store(),idx=hookIndex++; let slot=hooks[idx]; if(!slot)slot=hooks[idx]={deps:undefined,cleanup:undefined,pending:false,effect:null}; if(depsChanged(slot.deps,deps)){slot.deps=deps;slot.effect=effect;if(!slot.pending){slot.pending=true;(c.__simplePendingEffects||(c.__simplePendingEffects=[])).push(idx);}} }
  globalThis.React={createElement:P.createElement,Fragment:P.Fragment,useState,useEffect,useRef,useMemo,useCallback};
})();
(function(){
  if(!window.storage){window.storage={
    async get(key){const value=localStorage.getItem(key);return value===null?null:{value};},
    async set(key,value){localStorage.setItem(key,value);return {value};},
    async delete(key){localStorage.removeItem(key);return true;}
  };}
})();
const React = globalThis.React;
const { useState, useEffect, useRef, useMemo, useCallback } = React;
function __makeIcon(glyph) { return function Icon({ size = 20, color = 'currentColor', strokeWidth = 2, ...props }) { return React.createElement('span', { ...props, style: { display: 'inline-flex', width: size, height: size, alignItems: 'center', justifyContent: 'center', fontSize: Math.max(14, size * 0.82), lineHeight: 1, color, ...(props.style || {}) } }, glyph); }; }
const HomeIcon = __makeIcon("⌂");
const Target = __makeIcon("◎");
const BarChart3 = __makeIcon("▥");
const Trophy = __makeIcon("★");
const User = __makeIcon("●");
const Coffee = __makeIcon("☕");
const Bike = __makeIcon("🚲");
const ShoppingBag = __makeIcon("▣");
const Sofa = __makeIcon("▰");
const Gamepad2 = __makeIcon("✦");
const Smartphone = __makeIcon("▯");
const Lightbulb = __makeIcon("💡");
const Wallet = __makeIcon("▤");
const Check = __makeIcon("✓");
const RefreshCw = __makeIcon("↻");
const Plus = __makeIcon("＋");
const X = __makeIcon("×");
const ChevronLeft = __makeIcon("‹");
const ChevronRight = __makeIcon("›");
const Globe = __makeIcon("◉");
const Moon = __makeIcon("☾");
const Sun = __makeIcon("☀");
const Bell = __makeIcon("♢");
const Shield = __makeIcon("◆");
const FileText = __makeIcon("▧");
const Share2 = __makeIcon("↗");
const Star = __makeIcon("★");
const HelpCircle = __makeIcon("?");
const Flame = __makeIcon("♨");
const Sparkles = __makeIcon("✧");
const Pencil = __makeIcon("✎");
const Trash2 = __makeIcon("⌫");
const Crown = __makeIcon("♛");
const Leaf = __makeIcon("❧");
const TrendingUp = __makeIcon("↗");
const CalendarIcon = __makeIcon("▦");
const PiggyBank = __makeIcon("◈");
const ChevronDown = __makeIcon("⌄");
/* ---------------------------------------------------------------------- */
/* i18n                                                                    */
/* ---------------------------------------------------------------------- */
const STR = {
    ar: {
        appName: "وفّرها", tagline: "وفّر اليوم، ارتاح بكرا",
        ob1Title: "وفّر أكثر بدون تعقيد", ob1Body: "تحديات صغيرة كل يوم تساعدك على الاحتفاظ بالمزيد من أموالك.",
        ob2Title: "أنجز التحديات", ob2Body: "نفّذ تحديات بسيطة واكسب XP وحافظ على سلسلة التوفير.",
        ob3Title: "شاهد أموالك تكبر", ob3Body: "تابع مدخراتك وحدد هدفًا ماليًا واعرف مقدار تقدمك.",
        start: "ابدأ الآن", next: "التالي", skip: "تخطي",
        chooseLang: "اختر اللغة", chooseCurrency: "اختر العملة", yourName: "اسمك (اختياري)",
        yourNamePh: "مثال: سارة", savingGoal: "هدف التوفير", savingGoalPh: "المبلغ الذي تريد توفيره",
        finish: "دخول التطبيق",
        goodMorning: "صباح الخير 👋", goodAfternoon: "مساء الخير 👋", goodEvening: "مساء الخير 👋",
        totalSaved: "إجمالي ما وفّرته", thisMonth: "هذا الشهر",
        todayChallenge: "تحدّي اليوم", expectedSaving: "التوفير المتوقع", reward: "المكافأة",
        complete: "أنجزت التحدي", changeChallenge: "تغيير التحدي", completed: "تم الإنجاز 🎉",
        extraChallenges: "تحديات إضافية", howMuchSaved: "كم وفّرت فعليًا؟", confirm: "تأكيد",
        cancel: "إلغاء", level: "المستوى", xp: "XP", streak: "أيام متتالية", bestStreak: "أفضل سلسلة",
        goals: "أهدافي", newGoal: "هدف جديد", goalName: "اسم الهدف", targetAmount: "المبلغ المطلوب",
        deadlineOpt: "تاريخ الهدف (اختياري)", createGoal: "إنشاء الهدف", noGoals: "ما في أهداف بعد",
        noGoalsBody: "أنشئ هدفك الأول وابدأ بالتوفير له.", primary: "رئيسي", setPrimary: "تعيين كرئيسي",
        edit: "تعديل", delete: "حذف", history: "سجل التوفير", all: "الكل", today: "اليوم",
        week: "الأسبوع", month: "الشهر", noHistory: "لا يوجد سجل بعد", totalToday: "إجمالي اليوم",
        addManual: "إضافة توفير", manualPrompt: "شو وفّرت اليوم؟", manualPh: "مثال: لم أشترِ ملابس كنت أفكر بشرائها",
        amount: "المبلغ", category: "الفئة", noteOpt: "ملاحظة (اختياري)", add: "إضافة",
        stats: "الإحصائيات", totalSavings: "إجمالي التوفير", monthSaving: "توفير هذا الشهر",
        currentStreak: "السلسلة الحالية", totalXP: "إجمالي XP", completedChallenges: "تحديات مكتملة",
        dailyAvg: "متوسط التوفير اليومي", topCategory: "أكثر فئة وفّرت منها", last7: "٧ أيام",
        last30: "٣٠ يوم", last6m: "٦ أشهر", achievements: "الإنجازات", locked: "مقفل",
        unlocked: "مفتوح", profile: "حسابي", myGoals: "أهدافي", language: "اللغة", currency: "العملة",
        notifications: "الإشعارات", darkMode: "الوضع الداكن", help: "المساعدة", rateApp: "تقييم التطبيق",
        shareApp: "مشاركة التطبيق", privacy: "الخصوصية", terms: "الشروط والأحكام", premium: "وفّرها بريميوم",
        light: "فاتح", dark: "داكن", system: "تلقائي", save: "حفظ", close: "إغلاق",
        emptyChallengeTitle: "لا يوجد تحدٍ اليوم", createCustom: "إنشاء تحدٍ خاص",
        challengeName: "اسم التحدي", icon: "أيقونة", xpReward: "XP",
        catFood: "الطعام والمشروبات", catTransport: "المواصلات", catShopping: "التسوق",
        catHome: "المنزل", catEntertainment: "الترفيه", catSubs: "الاشتراكات",
        catHabits: "عادات يومية", catFinancial: "تحديات مالية",
        achName1: "البداية", achDesc1: "أكمل أول تحدٍ.",
        achName2: "أسبوع قوي", achDesc2: "حافظ على سلسلة لمدة 7 أيام.",
        achName3: "أول 100", achDesc3: "وفّر أول 100 من عملتك.",
        achName4: "بطل التحديات", achDesc4: "أكمل 20 تحديًا.",
        achName5: "سيد التوفير", achDesc5: "وفّر 1,000 من عملتك.",
        achName6: "محترف التوفير", achDesc6: "وصلت للمستوى 3.",
        achName7: "محقق الأهداف", achDesc7: "أكمل هدفًا ماليًا بالكامل.",
        achName8: "سلسلة أسطورية", achDesc8: "حقق أفضل سلسلة 21 يومًا.",
        lvl1: "مبتدئ التوفير", lvl2: "موفّر ذكي", lvl3: "محترف التوفير", lvl4: "خبير التوفير", lvl5: "ملك التوفير",
        of: "من", welcome: "أهلًا", editEntry: "تعديل العملية", deleteConfirm: "هل تريد حذف هذه العملية؟",
        yes: "نعم", no: "لا", premiumBody: "افتح مميزات إضافية قريبًا: أهداف غير محدودة، إحصائيات متقدمة، إزالة الإعلانات، Backup سحابي والمزيد.",
        comingSoon: "قريبًا", freeFeatures: "المجاني", premiumFeatures: "المميز",
        freeList: "تحديات يومية، هدف مالي واحد، إحصائيات أساسية، سجل التوفير",
        premiumList: "تحديات متقدمة، أهداف غير محدودة، إحصائيات متقدمة، إزالة الإعلانات، Badges خاصة، Backup سحابي",
        invalidAmount: "أدخل مبلغًا صحيحًا", newLevel: "مستوى جديد!", newAchievement: "إنجاز جديد!",
        goalReached: "وصلت لهدفك! 🎉", noEntries: "لا توجد عمليات", resetData: "إعادة ضبط البيانات",
        resetConfirm: "سيتم حذف كل بياناتك. هل أنت متأكد؟", about: "عن وفّرها",
        aboutBody: "وفّرها يساعدك على توفير المال من خلال تحديات يومية بسيطة وممتعة. لا نجمع بيانات مالية أو بنكية حساسة — نتابع فقط المبالغ التي تخبرنا أنك وفّرتها.",
        privacyBody: "لا نجمع أي بيانات مالية أو بنكية حقيقية. جميع البيانات تُحفظ محليًا مرتبطة بحسابك فقط ولا تُشارك مع أي طرف ثالث.",
        termsBody: "باستخدامك تطبيق وفّرها فأنت توافق على استخدامه لأغراض تتبع التوفير الشخصي فقط. الأرقام المعروضة تعتمد على ما تدخله بنفسك.",
        reminderTime: "وقت التذكير",
    },
    en: {
        appName: "Wafferha", tagline: "Save today. Enjoy tomorrow.",
        ob1Title: "Save more, without the hassle", ob1Body: "Small daily challenges that help you keep more of your money.",
        ob2Title: "Complete challenges", ob2Body: "Do simple challenges, earn XP, and keep your saving streak alive.",
        ob3Title: "Watch your money grow", ob3Body: "Track your savings, set a goal, and see your progress.",
        start: "Get started", next: "Next", skip: "Skip",
        chooseLang: "Choose language", chooseCurrency: "Choose currency", yourName: "Your name (optional)",
        yourNamePh: "e.g. Sara", savingGoal: "Savings goal", savingGoalPh: "Amount you want to save",
        finish: "Enter Wafferha",
        goodMorning: "Good morning 👋", goodAfternoon: "Good afternoon 👋", goodEvening: "Good evening 👋",
        totalSaved: "Total saved", thisMonth: "This month",
        todayChallenge: "Today's challenge", expectedSaving: "Expected saving", reward: "Reward",
        complete: "Mark as done", changeChallenge: "Change challenge", completed: "Completed 🎉",
        extraChallenges: "Extra challenges", howMuchSaved: "How much did you actually save?", confirm: "Confirm",
        cancel: "Cancel", level: "Level", xp: "XP", streak: "day streak", bestStreak: "Best streak",
        goals: "Goals", newGoal: "New goal", goalName: "Goal name", targetAmount: "Target amount",
        deadlineOpt: "Target date (optional)", createGoal: "Create goal", noGoals: "No goals yet",
        noGoalsBody: "Create your first goal and start saving toward it.", primary: "Primary", setPrimary: "Set as primary",
        edit: "Edit", delete: "Delete", history: "History", all: "All", today: "Today",
        week: "Week", month: "Month", noHistory: "No history yet", totalToday: "Today's total",
        addManual: "Add saving", manualPrompt: "What did you save today?", manualPh: "e.g. skipped buying clothes I was eyeing",
        amount: "Amount", category: "Category", noteOpt: "Note (optional)", add: "Add",
        stats: "Statistics", totalSavings: "Total savings", monthSaving: "This month's saving",
        currentStreak: "Current streak", totalXP: "Total XP", completedChallenges: "Completed challenges",
        dailyAvg: "Daily average saving", topCategory: "Top saving category", last7: "7 days",
        last30: "30 days", last6m: "6 months", achievements: "Achievements", locked: "Locked",
        unlocked: "Unlocked", profile: "Profile", myGoals: "My goals", language: "Language", currency: "Currency",
        notifications: "Notifications", darkMode: "Dark mode", help: "Help", rateApp: "Rate the app",
        shareApp: "Share the app", privacy: "Privacy", terms: "Terms of service", premium: "Wafferha Premium",
        light: "Light", dark: "Dark", system: "System", save: "Save", close: "Close",
        emptyChallengeTitle: "No challenge today", createCustom: "Create custom challenge",
        challengeName: "Challenge name", icon: "Icon", xpReward: "XP",
        catFood: "Food & Drinks", catTransport: "Transport", catShopping: "Shopping",
        catHome: "Home", catEntertainment: "Entertainment", catSubs: "Subscriptions",
        catHabits: "Daily habits", catFinancial: "Money moves",
        achName1: "Getting started", achDesc1: "Complete your first challenge.",
        achName2: "Strong week", achDesc2: "Keep a 7-day streak.",
        achName3: "First 100", achDesc3: "Save your first 100.",
        achName4: "Challenge champion", achDesc4: "Complete 20 challenges.",
        achName5: "Savings master", achDesc5: "Save 1,000.",
        achName6: "Saving pro", achDesc6: "Reach level 3.",
        achName7: "Goal getter", achDesc7: "Fully complete a savings goal.",
        achName8: "Legendary streak", achDesc8: "Hit a 21-day best streak.",
        lvl1: "Saving starter", lvl2: "Smart saver", lvl3: "Saving pro", lvl4: "Saving expert", lvl5: "Savings king",
        of: "of", welcome: "Welcome", editEntry: "Edit entry", deleteConfirm: "Delete this entry?",
        yes: "Yes", no: "No", premiumBody: "Unlock more soon: unlimited goals, advanced stats, no ads, cloud backup and more.",
        comingSoon: "Coming soon", freeFeatures: "Free", premiumFeatures: "Premium",
        freeList: "Daily challenges, one savings goal, basic stats, savings history",
        premiumList: "Advanced challenges, unlimited goals, advanced stats, no ads, special badges, cloud backup",
        invalidAmount: "Enter a valid amount", newLevel: "New level!", newAchievement: "New achievement!",
        goalReached: "Goal reached! 🎉", noEntries: "No entries", resetData: "Reset data",
        resetConfirm: "This will delete all your data. Are you sure?", about: "About Wafferha",
        aboutBody: "Wafferha helps you save money through small, fun daily challenges. We don't collect real financial or banking data — we only track the amounts you tell us you've saved.",
        privacyBody: "We don't collect any real financial or banking data. All data is stored locally and tied to your account only, never shared with third parties.",
        termsBody: "By using Wafferha you agree it's for personal savings tracking only. All numbers shown are based on what you enter yourself.",
        reminderTime: "Reminder time",
    },
};
const CURRENCIES = [
    { code: "USD", symbol: "$" }, { code: "EUR", symbol: "€" }, { code: "CAD", symbol: "$" },
    { code: "GBP", symbol: "£" }, { code: "SAR", symbol: "ر.س" }, { code: "AED", symbol: "د.إ" },
    { code: "TRY", symbol: "₺" },
];
const CATS = [
    { id: "food", icon: "🍔", ar: "catFood" }, { id: "transport", icon: "🚗", ar: "catTransport" },
    { id: "shopping", icon: "🛍️", ar: "catShopping" }, { id: "home", icon: "🏠", ar: "catHome" },
    { id: "entertainment", icon: "🎮", ar: "catEntertainment" }, { id: "subs", icon: "📱", ar: "catSubs" },
    { id: "habits", icon: "💡", ar: "catHabits" }, { id: "financial", icon: "💰", ar: "catFinancial" },
];
/* Challenge library: [id, category, icon, saving, xp, titleAr, descAr, titleEn, descEn] */
const LIBRARY = [
    ["c1", "food", "☕", 4, 20, "حضّر قهوتك في المنزل", "بدل شراء القهوة من الخارج، حضّرها في المنزل.", "Make coffee at home", "Instead of buying coffee out, brew it at home."],
    ["c2", "food", "🍱", 8, 30, "خذ غداءك من المنزل", "جهّز غداءك بدل شرائه بالخارج.", "Bring lunch from home", "Prep your lunch instead of buying it out."],
    ["c3", "food", "🥡", 15, 40, "لا تطلب توصيل طعام اليوم", "تجنب طلبات توصيل الطعام اليوم.", "Skip food delivery today", "Avoid ordering food delivery today."],
    ["c4", "food", "🍪", 3, 15, "اصنع وجبة خفيفة بنفسك", "بدل شراء سناك جاهز، حضّره بنفسك.", "Make your own snack", "Instead of buying a snack, make one at home."],
    ["c5", "food", "💧", 2, 10, "اشرب ماء بدل مشروب مشترى", "وفّر ثمن مشروب واشرب ماء بدل ذلك.", "Drink water instead of a bought drink", "Save the cost of a drink and have water instead."],
    ["c6", "food", "🍲", 10, 35, "اطبخ العشاء بالمنزل", "حضّر وجبة العشاء بنفسك بدل الطلب.", "Cook dinner at home", "Make dinner yourself instead of ordering."],
    ["c36", "food", "🧊", 3, 15, "اصنع القهوة المثلجة بنفسك", "حضّر قهوتك المثلجة بدل شرائها.", "Make your own iced coffee", "Brew your iced coffee instead of buying it."],
    ["c37", "food", "🥗", 6, 20, "تجنب شراء وجبات جاهزة", "حضّر وجبتك بدل شراء وجبة جاهزة.", "Skip pre-made meals", "Cook instead of buying a ready-made meal."],
    ["c46", "food", "🍿", 5, 15, "اصنع الفشار بالمنزل", "حضّر الفشار بدل شرائه بالسينما.", "Make popcorn at home", "Pop your own instead of buying at the cinema."],
    ["c7", "transport", "🚶", 5, 25, "امشِ بدل سيارة أو تاكسي", "لمسافة قصيرة، امشِ بدل استخدام مركبة.", "Walk instead of a taxi", "For a short trip, walk instead of driving."],
    ["c8", "transport", "🚌", 6, 25, "استخدم النقل العام", "خذ الباص أو المترو بدل التاكسي.", "Take public transit", "Use the bus or metro instead of a cab."],
    ["c9", "transport", "🚗", 5, 20, "شارك رحلة مع صديق", "وفّروا تكلفة المشوار سوا.", "Carpool with a friend", "Split the ride cost together."],
    ["c10", "transport", "🚲", 4, 20, "استخدم الدراجة بدل السيارة", "اختر الدراجة اليوم بدل السيارة.", "Ride a bike instead of driving", "Choose your bike today instead of the car."],
    ["c38", "transport", "🅿️", 2, 10, "اركن بعيدًا لتوفير رسوم الموقف", "اختر موقفًا أرخص أو أبعد قليلًا.", "Park a bit farther to save on fees", "Choose a cheaper, slightly farther spot."],
    ["c47", "transport", "🗺️", 6, 20, "خطط رحلاتك لتقليل القيادة", "اجمع مشاويرك في رحلة واحدة.", "Plan trips to drive less", "Combine errands into one trip."],
    ["c11", "shopping", "🛍️", 10, 30, "لا تشترِ شيئًا غير ضروري", "تجنب شراء شيء لست بحاجته اليوم.", "Skip an unnecessary purchase", "Avoid buying something you don't need today."],
    ["c12", "shopping", "🚫", 20, 50, "يوم بدون مشتريات", "لا تنفق أي مبلغ اليوم.", "A no-spend day", "Don't spend any money today."],
    ["c13", "shopping", "🔍", 5, 15, "قارن الأسعار قبل الشراء", "تحقق من أفضل سعر قبل الشراء.", "Compare prices before buying", "Check for the best price before buying."],
    ["c14", "shopping", "🎟️", 7, 20, "استخدم كوبون خصم", "استفد من خصم بدل الشراء بالسعر الكامل.", "Use a discount coupon", "Use a coupon instead of paying full price."],
    ["c15", "shopping", "⏳", 12, 25, "أجّل عملية شراء غير ضرورية", "انتظر 24 ساعة قبل الشراء.", "Delay a non-essential purchase", "Wait 24 hours before buying it."],
    ["c39", "shopping", "♻️", 20, 40, "اشترِ نسخة مستعملة بدل جديدة", "وفّر بشراء شيء مستعمل بحالة جيدة.", "Buy secondhand instead of new", "Save by buying something used in good shape."],
    ["c48", "shopping", "🏷️", 10, 25, "انتظر التخفيضات قبل الشراء", "لا تشترِ بالسعر الكامل، انتظر عرضًا.", "Wait for a sale before buying", "Skip full price and wait for a deal."],
    ["c16", "home", "🔌", 3, 15, "اطفئ الأجهزة غير المستخدمة", "افصل الأجهزة التي لا تستخدمها.", "Turn off unused appliances", "Unplug devices you're not using."],
    ["c17", "home", "🧺", 4, 15, "اغسل بحمولة كاملة", "اجمع الغسيل بحمولة كاملة بدل حمولات صغيرة.", "Do a full laundry load", "Wash a full load instead of small ones."],
    ["c18", "home", "🔧", 15, 35, "أصلح بدل الاستبدال", "أصلح شيئًا بدل شراء بديل جديد.", "Repair instead of replace", "Fix something instead of buying new."],
    ["c19", "home", "🍱", 10, 30, "اطبخ بكميات كبيرة", "حضّر وجبات الأسبوع دفعة واحدة.", "Meal-prep in bulk", "Cook this week's meals all at once."],
    ["c40", "home", "🌡️", 4, 15, "اخفض التدفئة أو التكييف درجة", "وفّر بضبط درجة الحرارة قليلًا.", "Lower the heating or AC by a degree", "Save by adjusting the temperature slightly."],
    ["c49", "home", "🧴", 5, 15, "اصنع منتج تنظيف منزلي بسيط", "بدل شراء منظف جاهز.", "Make a simple homemade cleaner", "Instead of buying one ready-made."],
    ["c20", "entertainment", "🎬", 12, 30, "شاهد فيلمًا بالمنزل", "بدل الذهاب للسينما.", "Watch a movie at home", "Instead of going to the cinema."],
    ["c21", "entertainment", "🏡", 15, 35, "استضف صديقًا بالمنزل", "بدل الخروج لمطعم.", "Host a friend at home", "Instead of eating out."],
    ["c22", "entertainment", "🎈", 10, 25, "اختر نشاطًا مجانيًا", "بدل نشاط مدفوع اليوم.", "Choose a free activity", "Instead of a paid one today."],
    ["c41", "entertainment", "📚", 8, 20, "استعر من المكتبة", "بدل شراء كتاب جديد.", "Borrow from the library", "Instead of buying a new book."],
    ["c23", "subs", "📵", 10, 40, "ألغِ اشتراكًا لا تستخدمه", "راجع اشتراكاتك وألغِ واحدًا غير مستخدم.", "Cancel an unused subscription", "Review and cancel one you don't use."],
    ["c24", "subs", "👨‍👩‍👧", "5", 20, "شارك اشتراك ستريمنغ", "شارك الاشتراك مع العائلة.", "Share a streaming subscription", "Split it with family."],
    ["c25", "subs", "📋", 5, 15, "راجع اشتراكاتك الشهرية", "تحقق من كل اشتراك فعّال.", "Review your monthly subscriptions", "Check every active subscription."],
    ["c42", "subs", "⬇️", 8, 25, "نزّل لخطة أرخص", "بدّل لخطة اشتراك أوفر.", "Downgrade to a cheaper plan", "Switch to a more affordable plan."],
    ["c26", "habits", "📝", 6, 20, "اصنع قائمة قبل التسوق", "تجنب الشراء الزائد بقائمة واضحة.", "Make a list before shopping", "Avoid overbuying with a clear list."],
    ["c27", "habits", "🚰", 2, 10, "احمل زجاجة ماء معك", "بدل شراء واحدة بالخارج.", "Carry a water bottle", "Instead of buying one out."],
    ["c28", "habits", "🎫", 5, 15, "استخدم نقاط الولاء", "استفد من نقاط أو قسائم متوفرة.", "Use loyalty points", "Redeem points or vouchers you have."],
    ["c29", "habits", "🛑", 8, 25, "تجنب شراء اندفاعي", "توقف قبل شراء شيء غير مخطط له.", "Avoid an impulse buy", "Pause before an unplanned purchase."],
    ["c30", "habits", "📊", 5, 20, "راجع ميزانيتك اليوم", "خذ 5 دقائق لمراجعة مصاريفك.", "Review your budget today", "Take 5 minutes to check your spending."],
    ["c43", "habits", "🗓️", 10, 25, "خطط وجباتك للأسبوع", "يقلل الشراء العشوائي والهدر.", "Plan your meals for the week", "Cuts down on random buys and waste."],
    ["c50", "habits", "🧮", 5, 15, "احسب التكلفة قبل الشراء", "توقف واحسب قبل الدفع.", "Calculate the cost before buying", "Pause and do the math before paying."],
    ["c31", "financial", "🐷", 10, 25, "ضع مبلغًا في حصالة التوفير", "أضف مبلغًا صغيرًا لمدخراتك.", "Add to your savings jar", "Put a small amount toward your savings."],
    ["c32", "financial", "🏦", 20, 40, "حوّل مبلغًا لحساب التوفير", "حوّل مبلغًا مباشرة لحساب التوفير.", "Transfer to your savings account", "Move an amount straight into savings."],
    ["c33", "financial", "💵", 25, 45, "بع شيئًا لا تحتاجه", "حوّل غرضًا غير مستخدم إلى مال.", "Sell something you don't need", "Turn an unused item into cash."],
    ["c34", "financial", "📶", 8, 25, "قارن عروض الهاتف أو الإنترنت", "ابحث عن خطة أوفر.", "Compare phone/internet plans", "Look for a cheaper plan."],
    ["c35", "financial", "🤝", 15, 35, "تفاوض على فاتورة اشتراك", "اتصل واطلب سعرًا أفضل.", "Negotiate a subscription bill", "Call and ask for a better rate."],
    ["c44", "financial", "🏛️", 5, 20, "افتح حساب توفير منفصل", "خصص حسابًا لهدفك المالي.", "Open a separate savings account", "Dedicate one to your savings goal."],
    ["c45", "financial", "🧾", 5, 20, "تتبع مصاريفك اليوم", "سجّل كل ما أنفقته اليوم.", "Track your spending today", "Log everything you spent today."],
];
const CHALLENGES = LIBRARY.map(([id, category, icon, saving, xp, titleAr, descAr, titleEn, descEn]) => ({
    id, category, icon, saving: Number(saving), xp,
    ar: { title: titleAr, desc: descAr }, en: { title: titleEn, desc: descEn },
}));
const ACHIEVEMENTS = [
    { id: "a1", icon: "🌱", nameKey: "achName1", descKey: "achDesc1", check: (s) => s.completedCount >= 1 },
    { id: "a2", icon: "🔥", nameKey: "achName2", descKey: "achDesc2", check: (s) => s.currentStreak >= 7 },
    { id: "a3", icon: "💯", nameKey: "achName3", descKey: "achDesc3", check: (s) => s.totalSavings >= 100 },
    { id: "a4", icon: "🏆", nameKey: "achName4", descKey: "achDesc4", check: (s) => s.completedCount >= 20 },
    { id: "a5", icon: "👑", nameKey: "achName5", descKey: "achDesc5", check: (s) => s.totalSavings >= 1000 },
    { id: "a6", icon: "🔥", nameKey: "achName6", descKey: "achDesc6", check: (s) => s.level >= 3 },
    { id: "a7", icon: "🎯", nameKey: "achName7", descKey: "achDesc7", check: (s) => s.hasCompletedGoal },
    { id: "a8", icon: "🌟", nameKey: "achName8", descKey: "achDesc8", check: (s) => s.bestStreak >= 21 },
];
const LEVELS = [
    { level: 1, key: "lvl1", min: 0, max: 99 },
    { level: 2, key: "lvl2", min: 100, max: 299 },
    { level: 3, key: "lvl3", min: 300, max: 699 },
    { level: 4, key: "lvl4", min: 700, max: 1499 },
    { level: 5, key: "lvl5", min: 1500, max: Infinity },
];
function getLevelInfo(xp) {
    const lvl = LEVELS.find((l) => xp >= l.min && xp <= l.max) || LEVELS[LEVELS.length - 1];
    const next = LEVELS.find((l) => l.level === lvl.level + 1);
    const progress = next ? (xp - lvl.min) / (next.min - lvl.min) : 1;
    return { ...lvl, next, progress: Math.min(1, Math.max(0, progress)) };
}
function todayISO(d = new Date()) { return d.toISOString().slice(0, 10); }
function daysAgo(n) { const d = new Date(); d.setDate(d.getDate() - n); return todayISO(d); }
function seedIndexForDate(dateStr, len) {
    let h = 0;
    for (let i = 0; i < dateStr.length; i++)
        h = (h * 31 + dateStr.charCodeAt(i)) >>> 0;
    return h % len;
}
/* ---------------------------------------------------------------------- */
const DEFAULT_STATE = {
    onboarded: false, language: "ar", currency: "USD", name: "", theme: "light",
    goalAmount: 1000,
    goals: [], history: [], customChallenges: [], dailyChallengeId: null,
    dailyChallengeDate: null, unlockedAchievements: [], notifications: true,
    notificationTime: "09:00", bestStreakStored: 0,
};
function formatMoney(amount, currencyCode, lang) {
    const cur = CURRENCIES.find((c) => c.code === currencyCode) || CURRENCIES[0];
    const n = Number(amount || 0);
    const formatted = n.toLocaleString(lang === "ar" ? "ar" : "en", { minimumFractionDigits: n % 1 === 0 ? 0 : 2, maximumFractionDigits: 2 });
    if (["USD", "CAD"].includes(cur.code))
        return `${cur.symbol}${formatted}`;
    if (cur.code === "EUR")
        return `${formatted}${cur.symbol}`;
    if (cur.code === "GBP")
        return `${cur.symbol}${formatted}`;
    return `${formatted} ${cur.symbol}`;
}
function WafferhaApp() {
    const [state, setState] = useState(null);
    const [loaded, setLoaded] = useState(false);
    const [tab, setTab] = useState("home");
    const [celebration, setCelebration] = useState(null);
    const saveTimer = useRef(null);
    useEffect(() => {
        (async () => {
            try {
                const res = await window.storage.get("wafferha:data");
                if (res && res.value)
                    setState({ ...DEFAULT_STATE, ...JSON.parse(res.value) });
                else
                    setState(DEFAULT_STATE);
            }
            catch (e) {
                setState(DEFAULT_STATE);
            }
            setLoaded(true);
        })();
    }, []);
    useEffect(() => {
        if (!loaded || !state)
            return;
        if (saveTimer.current)
            clearTimeout(saveTimer.current);
        saveTimer.current = setTimeout(() => {
            window.storage.set("wafferha:data", JSON.stringify(state), false).catch(() => { });
        }, 400);
        return () => clearTimeout(saveTimer.current);
    }, [state, loaded]);
    const lang = state?.language || "ar";
    const t = STR[lang];
    const dir = lang === "ar" ? "rtl" : "ltr";
    const dark = state?.theme === "dark";
    const allChallenges = useMemo(() => {
        if (!state)
            return CHALLENGES;
        return [...CHALLENGES, ...(state.customChallenges || [])];
    }, [state]);
    const derived = useMemo(() => {
        if (!state)
            return null;
        const history = state.history || [];
        const totalSavings = history.reduce((s, h) => s + h.amount, 0);
        const totalXP = history.reduce((s, h) => s + h.xp, 0);
        const monthKey = todayISO().slice(0, 7);
        const monthSaving = history.filter((h) => h.date.slice(0, 7) === monthKey).reduce((s, h) => s + h.amount, 0);
        const dateSet = new Set(history.map((h) => h.date));
        let currentStreak = 0;
        let cursor = new Date();
        if (!dateSet.has(todayISO(cursor)))
            cursor.setDate(cursor.getDate() - 1);
        while (dateSet.has(todayISO(cursor))) {
            currentStreak++;
            cursor.setDate(cursor.getDate() - 1);
        }
        let bestStreak = Math.max(state.bestStreakStored || 0, currentStreak);
        const completedCount = history.filter((h) => h.type === "challenge").length;
        const catTotals = {};
        history.forEach((h) => { catTotals[h.category] = (catTotals[h.category] || 0) + h.amount; });
        let topCategory = null;
        Object.entries(catTotals).forEach(([k, v]) => { if (!topCategory || v > topCategory.v)
            topCategory = { id: k, v }; });
        const level = getLevelInfo(totalXP);
        const hasCompletedGoal = (state.goals || []).some((g) => g.currentAmount >= g.targetAmount && g.targetAmount > 0);
        return { totalSavings, totalXP, monthSaving, currentStreak, bestStreak, completedCount, topCategory, level, hasCompletedGoal };
    }, [state]);
    const today = todayISO();
    // pick / rotate daily challenge
    useEffect(() => {
        if (!state || !derived)
            return;
        if (state.dailyChallengeDate !== today) {
            const idx = seedIndexForDate(today, CHALLENGES.length);
            const challenge = CHALLENGES[idx];
            setState((s) => ({ ...s, dailyChallengeId: challenge.id, dailyChallengeDate: today }));
        }
    }, [state?.dailyChallengeDate, today]);
    // achievement check
    useEffect(() => {
        if (!state || !derived)
            return;
        const newly = ACHIEVEMENTS.filter((a) => !state.unlockedAchievements.includes(a.id) && a.check(derived));
        if (newly.length > 0) {
            setState((s) => ({ ...s, unlockedAchievements: [...s.unlockedAchievements, ...newly.map((a) => a.id)], bestStreakStored: derived.bestStreak }));
            setCelebration({ type: "achievement", achievement: newly[0] });
        }
        else if (derived.bestStreak !== state.bestStreakStored) {
            setState((s) => ({ ...s, bestStreakStored: derived.bestStreak }));
        }
    }, [derived?.completedCount, derived?.currentStreak, derived?.totalSavings, derived?.level?.level, derived?.hasCompletedGoal]);
    if (!loaded || !state || !derived) {
        return (React.createElement("div", { style: { minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#F7F5EF" } },
            React.createElement("div", { style: { color: "#1B7A5B", fontFamily: "system-ui, -apple-system, Segoe UI, Tahoma, Arial, sans-serif", fontSize: 18 } }, "\uD83C\uDF31")));
    }
    const theme = dark
        ? { bg: "#0E1912", card: "#16241C", cardAlt: "#1C2E23", text: "#F2F6F1", sub: "#9DB3A6", primary: "#3BB08A", primaryDark: "#1B7A5B", border: "#24382C", accent: "#E8B04B" }
        : { bg: "#F7F5EF", card: "#FFFFFF", cardAlt: "#EFF6F1", text: "#1A2B21", sub: "#6B7C73", primary: "#1B7A5B", primaryDark: "#0F3D2E", border: "#E7E2D6", accent: "#E8B04B" };
    function updateGoalsForAmount(goals, amount) {
        let hitGoal = null;
        const updated = goals.map((g) => {
            if (g.isPrimary || goals.length === 1) {
                const wasComplete = g.currentAmount >= g.targetAmount && g.targetAmount > 0;
                const newCurrent = g.currentAmount + amount;
                if (!wasComplete && newCurrent >= g.targetAmount && g.targetAmount > 0)
                    hitGoal = g;
                return { ...g, currentAmount: newCurrent };
            }
            return g;
        });
        return { updated, hitGoal };
    }
    function completeChallenge(challenge, amount, isDaily) {
        const entry = {
            id: `h${Date.now()}`, date: today, title: lang === "ar" ? challenge.ar.title : challenge.en.title,
            icon: challenge.icon, category: challenge.category, amount, xp: challenge.xp,
            type: "challenge", challengeId: challenge.id, isDaily: !!isDaily,
        };
        const { updated, hitGoal } = updateGoalsForAmount(state.goals, amount);
        setState((s) => ({ ...s, history: [entry, ...s.history], goals: updated }));
        if (hitGoal)
            setTimeout(() => setCelebration({ type: "goal", goal: hitGoal }), 300);
        else
            setCelebration({ type: "challenge", entry });
    }
    function addManualSaving(amount, category, note) {
        const entry = { id: `h${Date.now()}`, date: today, title: note || (lang === "ar" ? "توفير يدوي" : "Manual saving"), icon: "✅", category, amount, xp: 15, type: "manual" };
        const { updated, hitGoal } = updateGoalsForAmount(state.goals, amount);
        setState((s) => ({ ...s, history: [entry, ...s.history], goals: updated }));
        if (hitGoal)
            setTimeout(() => setCelebration({ type: "goal", goal: hitGoal }), 300);
    }
    function deleteEntry(id) {
        setState((s) => {
            const entry = s.history.find((h) => h.id === id);
            let goals = s.goals;
            if (entry) {
                goals = s.goals.map((g) => (g.isPrimary || s.goals.length === 1) ? { ...g, currentAmount: Math.max(0, g.currentAmount - entry.amount) } : g);
            }
            return { ...s, history: s.history.filter((h) => h.id !== id), goals };
        });
    }
    function editEntry(id, newAmount) {
        setState((s) => {
            const entry = s.history.find((h) => h.id === id);
            if (!entry)
                return s;
            const diff = newAmount - entry.amount;
            const goals = s.goals.map((g) => (g.isPrimary || s.goals.length === 1) ? { ...g, currentAmount: Math.max(0, g.currentAmount + diff) } : g);
            return { ...s, history: s.history.map((h) => (h.id === id ? { ...h, amount: newAmount } : h)), goals };
        });
    }
    const ctx = { state, setState, derived, t, lang, dir, dark, theme, allChallenges, today, completeChallenge, addManualSaving, deleteEntry, editEntry, celebration, setCelebration };
    if (!state.onboarded)
        return React.createElement(Onboarding, { ctx: ctx });
    return (React.createElement("div", { dir: dir, style: { fontFamily: "system-ui, -apple-system, Segoe UI, Tahoma, Arial, sans-serif", background: theme.bg, minHeight: "100vh", color: theme.text } },
        React.createElement("style", null, `
        * { box-sizing: border-box; }
        .waf-scroll::-webkit-scrollbar { display: none; }
        @keyframes waf-pop { 0% { transform: scale(0.85); opacity:0 } 60% { transform: scale(1.04); opacity:1 } 100% { transform: scale(1); } }
        @keyframes waf-fade { from { opacity: 0; transform: translateY(6px);} to { opacity:1; transform:translateY(0);} }
        .waf-pop { animation: waf-pop 0.35s ease; }
        .waf-fade { animation: waf-fade 0.3s ease; }
        button { font-family: inherit; }
        input, select { font-family: inherit; }
      `),
        React.createElement("div", { style: { maxWidth: 460, margin: "0 auto", paddingBottom: 84, minHeight: "100vh", position: "relative" } },
            tab === "home" && React.createElement(HomeScreen, { ctx: ctx }),
            tab === "challenges" && React.createElement(ChallengesScreen, { ctx: ctx }),
            tab === "stats" && React.createElement(StatsScreen, { ctx: ctx }),
            tab === "achievements" && React.createElement(AchievementsScreen, { ctx: ctx }),
            tab === "profile" && React.createElement(ProfileScreen, { ctx: ctx })),
        React.createElement(BottomNav, { tab: tab, setTab: setTab, t: t, theme: theme, dir: dir }),
        celebration && React.createElement(CelebrationModal, { ctx: ctx })));
}
/* ---------------------------------------------------------------------- */
/* Onboarding                                                              */
/* ---------------------------------------------------------------------- */
function Onboarding({ ctx }) {
    const { state, setState } = ctx;
    const [step, setStep] = useState(0);
    const [lang, setLang] = useState("ar");
    const [currency, setCurrency] = useState("USD");
    const [name, setName] = useState("");
    const [goal, setGoal] = useState("1000");
    const t = STR[lang];
    const dir = lang === "ar" ? "rtl" : "ltr";
    const theme = { bg: "#0F3D2E", card: "#FFFFFF", text: "#0F3D2E", primary: "#1B7A5B", accent: "#E8B04B" };
    const pages = [
        { emoji: "💰", title: t.ob1Title, body: t.ob1Body },
        { emoji: "🎯", title: t.ob2Title, body: t.ob2Body },
        { emoji: "🌱", title: t.ob3Title, body: t.ob3Body },
    ];
    if (step < 3) {
        const p = pages[step];
        return (React.createElement("div", { dir: dir, style: { fontFamily: "system-ui, -apple-system, Segoe UI, Tahoma, Arial, sans-serif", minHeight: "100vh", background: `linear-gradient(160deg, #0F3D2E 0%, #1B7A5B 55%, #2FA37C 100%)`, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "space-between", padding: "48px 28px", color: "#fff" } },
            React.createElement("style", null, `@keyframes waf-float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-10px)} }`),
            React.createElement("div", { style: { display: "flex", gap: 6, alignSelf: dir === "rtl" ? "flex-end" : "flex-start" } }, pages.map((_, i) => React.createElement("div", { key: i, style: { width: i === step ? 22 : 8, height: 8, borderRadius: 4, background: i === step ? "#E8B04B" : "rgba(255,255,255,0.35)", transition: "all .25s" } }))),
            React.createElement("div", { style: { textAlign: "center" } },
                React.createElement("div", { style: { fontSize: 84, marginBottom: 28, animation: "waf-float 3s ease-in-out infinite" } }, p.emoji),
                React.createElement("h1", { style: { fontSize: 26, fontWeight: 800, marginBottom: 14, lineHeight: 1.4 } }, p.title),
                React.createElement("p", { style: { fontSize: 15.5, opacity: 0.85, lineHeight: 1.8, maxWidth: 320 } }, p.body)),
            React.createElement("div", { style: { width: "100%" } },
                React.createElement("button", { onClick: () => setStep(step + 1), style: { width: "100%", background: "#fff", color: "#0F3D2E", border: "none", borderRadius: 18, padding: "16px", fontSize: 16, fontWeight: 800, cursor: "pointer" } }, step === 2 ? t.start : t.next),
                step < 2 && React.createElement("button", { onClick: () => setStep(3), style: { width: "100%", background: "transparent", color: "rgba(255,255,255,0.7)", border: "none", padding: "12px", fontSize: 14, cursor: "pointer" } }, t.skip))));
    }
    return (React.createElement("div", { dir: dir, style: { fontFamily: "system-ui, -apple-system, Segoe UI, Tahoma, Arial, sans-serif", minHeight: "100vh", background: "#F7F5EF", padding: "32px 24px" } },
        React.createElement("div", { style: { maxWidth: 420, margin: "0 auto" } },
            React.createElement("div", { style: { textAlign: "center", marginBottom: 28 } },
                React.createElement("div", { style: { fontSize: 40 } }, "\uD83C\uDF31"),
                React.createElement("h2", { style: { color: "#0F3D2E", fontWeight: 800, fontSize: 22, margin: "8px 0 2px" } }, t.appName),
                React.createElement("p", { style: { color: "#6B7C73", fontSize: 13 } }, t.tagline)),
            React.createElement(Field, { label: t.chooseLang },
                React.createElement("div", { style: { display: "flex", gap: 10 } }, [{ k: "ar", l: "🇸🇦 العربية" }, { k: "en", l: "🇬🇧 English" }].map((o) => (React.createElement("button", { key: o.k, onClick: () => setLang(o.k), style: pillStyle(lang === o.k) }, o.l))))),
            React.createElement(Field, { label: t.chooseCurrency },
                React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: 8 } }, CURRENCIES.map((c) => (React.createElement("button", { key: c.code, onClick: () => setCurrency(c.code), style: pillStyle(currency === c.code) },
                    c.symbol,
                    " ",
                    c.code))))),
            React.createElement(Field, { label: t.yourName },
                React.createElement("input", { value: name, onChange: (e) => setName(e.target.value), placeholder: t.yourNamePh, style: inputStyle })),
            React.createElement(Field, { label: t.savingGoal },
                React.createElement("input", { value: goal, onChange: (e) => setGoal(e.target.value.replace(/[^0-9.]/g, "")), placeholder: t.savingGoalPh, inputMode: "decimal", style: inputStyle })),
            React.createElement("button", { onClick: () => setState((s) => ({ ...s, onboarded: true, language: lang, currency, name, goalAmount: Number(goal) || 1000, goals: [{ id: "g1", title: lang === "ar" ? "هدفي الأساسي" : "My main goal", icon: "🎯", targetAmount: Number(goal) || 1000, currentAmount: 0, deadline: "", isPrimary: true }] })), style: { width: "100%", marginTop: 8, background: "#1B7A5B", color: "#fff", border: "none", borderRadius: 18, padding: "16px", fontSize: 16, fontWeight: 800, cursor: "pointer" } }, t.finish))));
}
function Field({ label, children }) {
    return (React.createElement("div", { style: { marginBottom: 20 } },
        React.createElement("div", { style: { fontSize: 13, fontWeight: 700, color: "#0F3D2E", marginBottom: 8 } }, label),
        children));
}
const inputStyle = { width: "100%", padding: "14px 16px", borderRadius: 14, border: "1.5px solid #E7E2D6", background: "#fff", fontSize: 15, color: "#1A2B21", outline: "none" };
function pillStyle(active) {
    return { padding: "10px 16px", borderRadius: 999, border: active ? "1.5px solid #1B7A5B" : "1.5px solid #E7E2D6", background: active ? "#1B7A5B" : "#fff", color: active ? "#fff" : "#1A2B21", fontSize: 13.5, fontWeight: 700, cursor: "pointer" };
}
/* ---------------------------------------------------------------------- */
/* Shared bits                                                             */
/* ---------------------------------------------------------------------- */
function Header({ title, theme }) {
    return React.createElement("div", { style: { padding: "20px 20px 4px", fontSize: 20, fontWeight: 800, color: theme.text } }, title);
}
function BottomNav({ tab, setTab, t, theme, dir }) {
    const items = [
        { k: "home", icon: HomeIcon, label: t.appName === "وفّرها" ? "الرئيسية" : "Home" },
        { k: "challenges", icon: Target, label: t.goals === "أهدافي" ? "التحديات" : "Challenges" },
        { k: "stats", icon: BarChart3, label: t.stats },
        { k: "achievements", icon: Trophy, label: t.achievements },
        { k: "profile", icon: User, label: t.profile },
    ];
    return (React.createElement("div", { style: { position: "fixed", bottom: 0, left: 0, right: 0, background: theme.card, borderTop: `1px solid ${theme.border}`, display: "flex", justifyContent: "center", zIndex: 40 } },
        React.createElement("div", { style: { maxWidth: 460, width: "100%", display: "flex" } }, items.map((it) => {
            const Icon = it.icon;
            const active = tab === it.k;
            return (React.createElement("button", { key: it.k, onClick: () => setTab(it.k), style: { flex: 1, background: "none", border: "none", padding: "10px 4px 12px", display: "flex", flexDirection: "column", alignItems: "center", gap: 4, cursor: "pointer" } },
                React.createElement(Icon, { size: 22, color: active ? theme.primary : theme.sub, strokeWidth: active ? 2.4 : 2 }),
                React.createElement("span", { style: { fontSize: 10.5, fontWeight: active ? 800 : 600, color: active ? theme.primary : theme.sub } }, it.label)));
        }))));
}
function catLabel(catId, t) {
    const c = CATS.find((c) => c.id === catId);
    return c ? t[c.ar] : catId;
}
function catIcon(catId) {
    const c = CATS.find((c) => c.id === catId);
    return c ? c.icon : "💰";
}
/* ---------------------------------------------------------------------- */
/* Home                                                                     */
/* ---------------------------------------------------------------------- */
function HomeScreen({ ctx }) {
    const { state, derived, t, lang, theme, allChallenges, today, completeChallenge } = ctx;
    const [amountModal, setAmountModal] = useState(null);
    const hour = new Date().getHours();
    const greeting = hour < 12 ? t.goodMorning : hour < 18 ? t.goodAfternoon : t.goodEvening;
    const daily = allChallenges.find((c) => c.id === state.dailyChallengeId) || allChallenges[0];
    const dailyDoneEntry = state.history.find((h) => h.date === today && h.challengeId === daily.id && h.isDaily);
    const primaryGoal = state.goals.find((g) => g.isPrimary) || state.goals[0];
    const goalTarget = primaryGoal ? primaryGoal.targetAmount : state.goalAmount;
    const goalCurrent = primaryGoal ? primaryGoal.currentAmount : derived.totalSavings;
    const goalPct = goalTarget > 0 ? Math.min(100, (goalCurrent / goalTarget) * 100) : 0;
    const extras = allChallenges.filter((c) => c.id !== daily.id).slice(0, 6);
    const extraDoneIds = new Set(state.history.filter((h) => h.date === today && h.type === "challenge").map((h) => h.challengeId));
    function rerollDaily() {
        const others = CHALLENGES.filter((c) => c.id !== daily.id);
        const pick = others[Math.floor(Math.random() * others.length)];
        ctx.setState((s) => ({ ...s, dailyChallengeId: pick.id }));
    }
    return (React.createElement("div", { className: "waf-fade" },
        React.createElement("div", { style: { padding: "22px 20px 6px", display: "flex", alignItems: "center", justifyContent: "space-between" } },
            React.createElement("div", null,
                React.createElement("div", { style: { fontSize: 20, fontWeight: 800, color: theme.text } },
                    "\uD83C\uDF31 ",
                    t.appName),
                React.createElement("div", { style: { fontSize: 13, color: theme.sub, marginTop: 2 } },
                    greeting,
                    state.name ? `، ${state.name}` : "")),
            React.createElement("div", { style: { width: 42, height: 42, borderRadius: 14, background: theme.cardAlt, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, fontWeight: 800, color: theme.primary } }, (state.name || "W").charAt(0).toUpperCase())),
        React.createElement("div", { style: { margin: "14px 20px", background: `linear-gradient(135deg, ${theme.primaryDark}, ${theme.primary})`, borderRadius: 24, padding: 22, color: "#fff", boxShadow: "0 12px 28px -14px rgba(15,61,46,0.55)" } },
            React.createElement("div", { style: { fontSize: 13, opacity: 0.85 } }, t.totalSaved),
            React.createElement("div", { style: { fontSize: 34, fontWeight: 800, margin: "4px 0 10px" } }, formatMoney(derived.totalSavings, state.currency, lang)),
            React.createElement("div", { style: { fontSize: 12.5, opacity: 0.85, marginBottom: 10 } },
                t.thisMonth,
                ": ",
                formatMoney(derived.monthSaving, state.currency, lang)),
            React.createElement("div", { style: { height: 8, borderRadius: 6, background: "rgba(255,255,255,0.22)", overflow: "hidden" } },
                React.createElement("div", { style: { height: "100%", width: `${goalPct}%`, background: theme.accent, borderRadius: 6, transition: "width .4s" } })),
            React.createElement("div", { style: { display: "flex", justifyContent: "space-between", marginTop: 8, fontSize: 12 } },
                React.createElement("span", null,
                    formatMoney(goalCurrent, state.currency, lang),
                    " / ",
                    formatMoney(goalTarget, state.currency, lang)),
                React.createElement("span", null,
                    goalPct.toFixed(0),
                    "%"))),
        React.createElement("div", { style: { margin: "0 20px 16px", display: "flex", gap: 10 } },
            React.createElement("div", { style: { flex: 1, background: theme.card, borderRadius: 18, padding: 14, border: `1px solid ${theme.border}` } },
                React.createElement("div", { style: { fontSize: 11, color: theme.sub, fontWeight: 700 } },
                    t.level,
                    " ",
                    derived.level.level,
                    " \u00B7 ",
                    t[derived.level.key]),
                React.createElement("div", { style: { height: 6, borderRadius: 4, background: theme.cardAlt, marginTop: 8, overflow: "hidden" } },
                    React.createElement("div", { style: { height: "100%", width: `${derived.level.progress * 100}%`, background: theme.primary, borderRadius: 4 } })),
                React.createElement("div", { style: { fontSize: 10.5, color: theme.sub, marginTop: 6 } },
                    derived.totalXP,
                    " XP")),
            React.createElement("div", { style: { flex: 1, background: theme.card, borderRadius: 18, padding: 14, border: `1px solid ${theme.border}`, display: "flex", alignItems: "center", gap: 10 } },
                React.createElement("div", { style: { fontSize: 26 } }, "\uD83D\uDD25"),
                React.createElement("div", null,
                    React.createElement("div", { style: { fontSize: 17, fontWeight: 800, color: theme.text } }, derived.currentStreak),
                    React.createElement("div", { style: { fontSize: 10.5, color: theme.sub } }, t.streak)))),
        React.createElement("div", { style: { margin: "0 20px 16px" } },
            React.createElement("div", { style: { fontSize: 15, fontWeight: 800, color: theme.text, marginBottom: 10 } },
                "\uD83D\uDCC5 ",
                t.todayChallenge),
            React.createElement("div", { style: { background: theme.card, borderRadius: 22, padding: 20, border: `1px solid ${theme.border}`, boxShadow: dailyDoneEntry ? "none" : "0 10px 24px -16px rgba(0,0,0,0.25)" } },
                React.createElement("div", { style: { display: "flex", alignItems: "flex-start", gap: 12 } },
                    React.createElement("div", { style: { width: 48, height: 48, borderRadius: 14, background: theme.cardAlt, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, flexShrink: 0 } }, daily.icon),
                    React.createElement("div", null,
                        React.createElement("div", { style: { fontSize: 16, fontWeight: 800, color: theme.text } }, lang === "ar" ? daily.ar.title : daily.en.title),
                        React.createElement("div", { style: { fontSize: 13, color: theme.sub, marginTop: 3, lineHeight: 1.6 } }, lang === "ar" ? daily.ar.desc : daily.en.desc))),
                React.createElement("div", { style: { display: "flex", gap: 16, margin: "14px 0" } },
                    React.createElement("div", { style: { fontSize: 12.5, color: theme.primary, fontWeight: 700 } },
                        "\uD83D\uDCB0 ",
                        t.expectedSaving,
                        ": ",
                        formatMoney(daily.saving, state.currency, lang)),
                    React.createElement("div", { style: { fontSize: 12.5, color: theme.accent, fontWeight: 700 } },
                        "\u2B50 +",
                        daily.xp,
                        " XP")),
                dailyDoneEntry ? (React.createElement("div", { style: { textAlign: "center", padding: "13px", borderRadius: 14, background: theme.cardAlt, color: theme.primary, fontWeight: 800, fontSize: 14 } }, t.completed)) : (React.createElement("div", { style: { display: "flex", gap: 8 } },
                    React.createElement("button", { onClick: () => setAmountModal({ challenge: daily, isDaily: true }), style: { flex: 1, background: theme.primary, color: "#fff", border: "none", borderRadius: 14, padding: "13px", fontSize: 14, fontWeight: 800, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 } },
                        React.createElement(Check, { size: 17 }),
                        " ",
                        t.complete),
                    React.createElement("button", { onClick: rerollDaily, title: t.changeChallenge, style: { background: theme.cardAlt, color: theme.text, border: "none", borderRadius: 14, width: 46, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" } },
                        React.createElement(RefreshCw, { size: 17 })))))),
        React.createElement("div", { style: { margin: "0 20px 16px" } },
            React.createElement("div", { style: { fontSize: 15, fontWeight: 800, color: theme.text, marginBottom: 10 } }, t.extraChallenges),
            React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: 10 } }, extras.map((c) => {
                const done = extraDoneIds.has(c.id);
                return (React.createElement("div", { key: c.id, style: { background: theme.card, borderRadius: 16, padding: 14, border: `1px solid ${theme.border}`, display: "flex", alignItems: "center", gap: 12 } },
                    React.createElement("div", { style: { fontSize: 22 } }, c.icon),
                    React.createElement("div", { style: { flex: 1 } },
                        React.createElement("div", { style: { fontSize: 13.5, fontWeight: 700, color: theme.text } }, lang === "ar" ? c.ar.title : c.en.title),
                        React.createElement("div", { style: { fontSize: 11.5, color: theme.sub, marginTop: 2 } },
                            formatMoney(c.saving, state.currency, lang),
                            " \u00B7 +",
                            c.xp,
                            " XP")),
                    done ? (React.createElement("div", { style: { width: 34, height: 34, borderRadius: 10, background: theme.cardAlt, display: "flex", alignItems: "center", justifyContent: "center" } },
                        React.createElement(Check, { size: 17, color: theme.primary }))) : (React.createElement("button", { onClick: () => setAmountModal({ challenge: c, isDaily: false }), style: { width: 34, height: 34, borderRadius: 10, background: theme.primary, border: "none", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" } },
                        React.createElement(Plus, { size: 18 })))));
            }))),
        amountModal && (React.createElement(AmountModal, { ctx: ctx, challenge: amountModal.challenge, onClose: () => setAmountModal(null), onConfirm: (amt) => { completeChallenge(amountModal.challenge, amt, amountModal.isDaily); setAmountModal(null); } }))));
}
function AmountModal({ ctx, challenge, onClose, onConfirm }) {
    const { t, theme, state, lang } = ctx;
    const [val, setVal] = useState(String(challenge.saving));
    const [err, setErr] = useState(false);
    return (React.createElement(ModalShell, { onClose: onClose, theme: theme },
        React.createElement("div", { style: { fontSize: 30, marginBottom: 8 } }, challenge.icon),
        React.createElement("div", { style: { fontSize: 16, fontWeight: 800, color: theme.text, marginBottom: 4 } }, lang === "ar" ? challenge.ar.title : challenge.en.title),
        React.createElement("div", { style: { fontSize: 13, color: theme.sub, marginBottom: 18 } }, t.howMuchSaved),
        React.createElement("div", { style: { position: "relative", marginBottom: err ? 6 : 20 } },
            React.createElement("input", { value: val, onChange: (e) => { setVal(e.target.value.replace(/[^0-9.]/g, "")); setErr(false); }, inputMode: "decimal", autoFocus: true, style: { width: "100%", padding: "16px", borderRadius: 14, border: `1.5px solid ${err ? "#E0554E" : theme.border}`, background: theme.bg, color: theme.text, fontSize: 22, fontWeight: 800, textAlign: "center", outline: "none" } })),
        err && React.createElement("div", { style: { color: "#E0554E", fontSize: 12, marginBottom: 14 } }, t.invalidAmount),
        React.createElement("div", { style: { display: "flex", gap: 10 } },
            React.createElement("button", { onClick: onClose, style: { flex: 1, padding: "13px", borderRadius: 14, border: `1px solid ${theme.border}`, background: "transparent", color: theme.text, fontWeight: 700, cursor: "pointer" } }, t.cancel),
            React.createElement("button", { onClick: () => { const n = parseFloat(val); if (isNaN(n) || n < 0) {
                    setErr(true);
                    return;
                } onConfirm(n); }, style: { flex: 1, padding: "13px", borderRadius: 14, border: "none", background: theme.primary, color: "#fff", fontWeight: 800, cursor: "pointer" } }, t.confirm))));
}
function ModalShell({ children, onClose, theme }) {
    return (React.createElement("div", { onClick: onClose, style: { position: "fixed", inset: 0, background: "rgba(10,20,15,0.55)", display: "flex", alignItems: "flex-end", justifyContent: "center", zIndex: 60 } },
        React.createElement("div", { onClick: (e) => e.stopPropagation(), className: "waf-pop", style: { width: "100%", maxWidth: 460, background: theme.card, borderRadius: "26px 26px 0 0", padding: "26px 22px 30px", textAlign: "center" } },
            React.createElement("div", { style: { width: 40, height: 4, borderRadius: 3, background: theme.border, margin: "0 auto 18px" } }),
            children)));
}
/* ---------------------------------------------------------------------- */
/* Celebration                                                             */
/* ---------------------------------------------------------------------- */
function CelebrationModal({ ctx }) {
    const { celebration, setCelebration, t, theme, lang, state } = ctx;
    if (!celebration)
        return null;
    let icon = "🎉", title = "", body = "";
    if (celebration.type === "challenge") {
        icon = "🎉";
        title = t.completed.replace(" 🎉", "");
        body = `+${formatMoney(celebration.entry.amount, state.currency, lang)} · +${celebration.entry.xp} XP`;
    }
    else if (celebration.type === "achievement") {
        icon = celebration.achievement.icon;
        title = t.newAchievement;
        body = t[celebration.achievement.nameKey];
    }
    else if (celebration.type === "goal") {
        icon = "🏆";
        title = t.goalReached;
        body = celebration.goal.title;
    }
    return (React.createElement("div", { onClick: () => setCelebration(null), style: { position: "fixed", inset: 0, background: "rgba(10,20,15,0.55)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 70, padding: 24 } },
        React.createElement("div", { className: "waf-pop", style: { background: theme.card, borderRadius: 26, padding: "34px 26px", textAlign: "center", maxWidth: 320 } },
            React.createElement("div", { style: { fontSize: 56, marginBottom: 12 } }, icon),
            React.createElement("div", { style: { fontSize: 18, fontWeight: 800, color: theme.text, marginBottom: 6 } }, title),
            React.createElement("div", { style: { fontSize: 13.5, color: theme.sub, marginBottom: 20 } }, body),
            React.createElement("button", { onClick: () => setCelebration(null), style: { width: "100%", padding: "13px", borderRadius: 14, border: "none", background: theme.primary, color: "#fff", fontWeight: 800, cursor: "pointer" } }, t.close))));
}
/* ---------------------------------------------------------------------- */
/* Challenges tab: extra challenges browser + goals + history + custom     */
/* ---------------------------------------------------------------------- */
function ChallengesScreen({ ctx }) {
    const { t, theme } = ctx;
    const [sub, setSub] = useState("goals");
    const tabs = [
        { k: "goals", label: t.goals },
        { k: "history", label: t.history },
        { k: "custom", label: t.createCustom },
    ];
    return (React.createElement("div", { className: "waf-fade" },
        React.createElement(Header, { title: `🎯 ${t.goals === "أهدافي" ? "التحديات" : "Challenges"}`, theme: theme }),
        React.createElement("div", { style: { display: "flex", gap: 8, padding: "8px 20px 16px" } }, tabs.map((s) => (React.createElement("button", { key: s.k, onClick: () => setSub(s.k), style: { padding: "8px 14px", borderRadius: 999, border: sub === s.k ? "none" : `1px solid ${theme.border}`, background: sub === s.k ? theme.primary : "transparent", color: sub === s.k ? "#fff" : theme.text, fontSize: 12.5, fontWeight: 700, cursor: "pointer" } }, s.label)))),
        sub === "goals" && React.createElement(GoalsPanel, { ctx: ctx }),
        sub === "history" && React.createElement(HistoryPanel, { ctx: ctx }),
        sub === "custom" && React.createElement(CustomChallengePanel, { ctx: ctx })));
}
function GoalsPanel({ ctx }) {
    const { state, setState, t, theme, lang } = ctx;
    const [form, setForm] = useState(null);
    function saveGoal(data) {
        if (data.id) {
            setState((s) => ({ ...s, goals: s.goals.map((g) => (g.id === data.id ? { ...g, ...data } : g)) }));
        }
        else {
            const newGoal = { id: `g${Date.now()}`, icon: "🎯", currentAmount: 0, isPrimary: state.goals.length === 0, ...data };
            setState((s) => ({ ...s, goals: [...s.goals, newGoal] }));
        }
        setForm(null);
    }
    function deleteGoal(id) {
        setState((s) => {
            const goals = s.goals.filter((g) => g.id !== id);
            if (goals.length && !goals.some((g) => g.isPrimary))
                goals[0].isPrimary = true;
            return { ...s, goals };
        });
    }
    function setPrimary(id) {
        setState((s) => ({ ...s, goals: s.goals.map((g) => ({ ...g, isPrimary: g.id === id })) }));
    }
    return (React.createElement("div", { style: { padding: "0 20px" } },
        React.createElement("button", { onClick: () => setForm({}), style: { width: "100%", padding: "13px", borderRadius: 14, border: `1.5px dashed ${theme.primary}`, background: "transparent", color: theme.primary, fontWeight: 800, fontSize: 13.5, cursor: "pointer", marginBottom: 16, display: "flex", alignItems: "center", justifyContent: "center", gap: 6 } },
            React.createElement(Plus, { size: 16 }),
            " ",
            t.newGoal),
        state.goals.length === 0 && React.createElement(EmptyState, { icon: "\uD83C\uDFAF", title: t.noGoals, body: t.noGoalsBody, theme: theme }),
        React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: 12 } }, state.goals.map((g) => {
            const pct = g.targetAmount > 0 ? Math.min(100, (g.currentAmount / g.targetAmount) * 100) : 0;
            return (React.createElement("div", { key: g.id, style: { background: theme.card, borderRadius: 18, padding: 16, border: `1px solid ${theme.border}` } },
                React.createElement("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "flex-start" } },
                    React.createElement("div", { style: { display: "flex", gap: 10, alignItems: "center" } },
                        React.createElement("div", { style: { fontSize: 22 } }, g.icon),
                        React.createElement("div", null,
                            React.createElement("div", { style: { fontWeight: 800, fontSize: 14.5, color: theme.text } }, g.title),
                            g.isPrimary && React.createElement("div", { style: { fontSize: 10.5, color: theme.primary, fontWeight: 700 } },
                                "\u2605 ",
                                t.primary))),
                    React.createElement("div", { style: { display: "flex", gap: 6 } },
                        React.createElement("button", { onClick: () => setForm(g), style: iconBtn(theme) },
                            React.createElement(Pencil, { size: 14 })),
                        React.createElement("button", { onClick: () => deleteGoal(g.id), style: iconBtn(theme) },
                            React.createElement(Trash2, { size: 14 })))),
                React.createElement("div", { style: { height: 8, borderRadius: 5, background: theme.cardAlt, marginTop: 14, overflow: "hidden" } },
                    React.createElement("div", { style: { height: "100%", width: `${pct}%`, background: theme.primary, borderRadius: 5 } })),
                React.createElement("div", { style: { display: "flex", justifyContent: "space-between", marginTop: 8, fontSize: 12, color: theme.sub } },
                    React.createElement("span", null,
                        formatMoney(g.currentAmount, state.currency, lang),
                        " ",
                        t.of,
                        " ",
                        formatMoney(g.targetAmount, state.currency, lang)),
                    React.createElement("span", { style: { fontWeight: 700 } },
                        pct.toFixed(0),
                        "%")),
                !g.isPrimary && React.createElement("button", { onClick: () => setPrimary(g.id), style: { marginTop: 10, background: "none", border: "none", color: theme.primary, fontSize: 12, fontWeight: 700, cursor: "pointer", padding: 0 } }, t.setPrimary)));
        })),
        form && React.createElement(GoalForm, { goal: form, onClose: () => setForm(null), onSave: saveGoal, t: t, theme: theme })));
}
function GoalForm({ goal, onClose, onSave, t, theme }) {
    const [title, setTitle] = useState(goal.title || "");
    const [amount, setAmount] = useState(goal.targetAmount ? String(goal.targetAmount) : "");
    const [deadline, setDeadline] = useState(goal.deadline || "");
    const [icon, setIcon] = useState(goal.icon || "🎯");
    return (React.createElement(ModalShell, { onClose: onClose, theme: theme },
        React.createElement("div", { style: { fontSize: 16, fontWeight: 800, color: theme.text, marginBottom: 16 } }, goal.id ? t.edit : t.newGoal),
        React.createElement("div", { style: { display: "flex", gap: 8, marginBottom: 12 } }, ["🎯", "✈️", "🏠", "🚗", "💍", "🎓", "📱", "🏖️"].map((e) => (React.createElement("button", { key: e, onClick: () => setIcon(e), style: { width: 36, height: 36, borderRadius: 10, border: icon === e ? `2px solid ${theme.primary}` : `1px solid ${theme.border}`, background: theme.bg, fontSize: 17, cursor: "pointer" } }, e)))),
        React.createElement("input", { value: title, onChange: (e) => setTitle(e.target.value), placeholder: t.goalName, style: { ...inputStyle, background: theme.bg, color: theme.text, borderColor: theme.border, marginBottom: 10 } }),
        React.createElement("input", { value: amount, onChange: (e) => setAmount(e.target.value.replace(/[^0-9.]/g, "")), placeholder: t.targetAmount, inputMode: "decimal", style: { ...inputStyle, background: theme.bg, color: theme.text, borderColor: theme.border, marginBottom: 10 } }),
        React.createElement("input", { value: deadline, onChange: (e) => setDeadline(e.target.value), type: "date", placeholder: t.deadlineOpt, style: { ...inputStyle, background: theme.bg, color: theme.text, borderColor: theme.border, marginBottom: 16 } }),
        React.createElement("div", { style: { display: "flex", gap: 10 } },
            React.createElement("button", { onClick: onClose, style: { flex: 1, padding: "13px", borderRadius: 14, border: `1px solid ${theme.border}`, background: "transparent", color: theme.text, fontWeight: 700, cursor: "pointer" } }, t.cancel),
            React.createElement("button", { onClick: () => { if (!title || !amount)
                    return; onSave({ id: goal.id, title, targetAmount: parseFloat(amount), deadline, icon }); }, style: { flex: 1, padding: "13px", borderRadius: 14, border: "none", background: theme.primary, color: "#fff", fontWeight: 800, cursor: "pointer" } }, t.save))));
}
function iconBtn(theme) {
    return { width: 30, height: 30, borderRadius: 9, border: `1px solid ${theme.border}`, background: theme.bg, color: theme.sub, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" };
}
function EmptyState({ icon, title, body, theme, action }) {
    return (React.createElement("div", { style: { textAlign: "center", padding: "40px 20px", color: theme.sub } },
        React.createElement("div", { style: { fontSize: 40, marginBottom: 10 } }, icon),
        React.createElement("div", { style: { fontWeight: 800, fontSize: 15, color: theme.text, marginBottom: 4 } }, title),
        React.createElement("div", { style: { fontSize: 13, lineHeight: 1.6 } }, body),
        action));
}
function HistoryPanel({ ctx }) {
    const { state, t, theme, lang, deleteEntry, editEntry } = ctx;
    const [filter, setFilter] = useState("all");
    const [editing, setEditing] = useState(null);
    const [confirmDelete, setConfirmDelete] = useState(null);
    const filtered = useMemo(() => {
        const h = state.history;
        if (filter === "today")
            return h.filter((x) => x.date === todayISO());
        if (filter === "week")
            return h.filter((x) => x.date >= daysAgo(6));
        if (filter === "month")
            return h.filter((x) => x.date >= daysAgo(29));
        return h;
    }, [state.history, filter]);
    const groups = useMemo(() => {
        const g = {};
        filtered.forEach((h) => { (g[h.date] = g[h.date] || []).push(h); });
        return Object.entries(g).sort((a, b) => (a[0] < b[0] ? 1 : -1));
    }, [filtered]);
    return (React.createElement("div", { style: { padding: "0 20px" } },
        React.createElement("div", { style: { display: "flex", gap: 6, marginBottom: 16, overflowX: "auto" }, className: "waf-scroll" }, [["all", t.all], ["today", t.today], ["week", t.week], ["month", t.month]].map(([k, l]) => (React.createElement("button", { key: k, onClick: () => setFilter(k), style: { padding: "7px 13px", borderRadius: 999, border: filter === k ? "none" : `1px solid ${theme.border}`, background: filter === k ? theme.primaryDark : "transparent", color: filter === k ? "#fff" : theme.text, fontSize: 12, fontWeight: 700, cursor: "pointer", whiteSpace: "nowrap" } }, l)))),
        groups.length === 0 && React.createElement(EmptyState, { icon: "\uD83D\uDCCA", title: t.noHistory, body: "", theme: theme }),
        groups.map(([date, entries]) => {
            const dayTotal = entries.reduce((s, e) => s + e.amount, 0);
            return (React.createElement("div", { key: date, style: { marginBottom: 18 } },
                React.createElement("div", { style: { display: "flex", justifyContent: "space-between", marginBottom: 8, fontSize: 12, color: theme.sub, fontWeight: 700 } },
                    React.createElement("span", null, new Date(date).toLocaleDateString(lang === "ar" ? "ar" : "en", { day: "numeric", month: "long" })),
                    React.createElement("span", null,
                        t.totalToday,
                        ": ",
                        formatMoney(dayTotal, state.currency, lang))),
                React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: 8 } }, entries.map((e) => (React.createElement("div", { key: e.id, style: { background: theme.card, borderRadius: 14, padding: 12, border: `1px solid ${theme.border}`, display: "flex", alignItems: "center", gap: 10 } },
                    React.createElement("div", { style: { fontSize: 20 } }, e.icon),
                    React.createElement("div", { style: { flex: 1 } },
                        React.createElement("div", { style: { fontSize: 13, fontWeight: 700, color: theme.text } }, e.title),
                        React.createElement("div", { style: { fontSize: 11, color: theme.sub } },
                            "+",
                            formatMoney(e.amount, state.currency, lang),
                            " \u00B7 +",
                            e.xp,
                            " XP")),
                    React.createElement("button", { onClick: () => setEditing(e), style: iconBtn(theme) },
                        React.createElement(Pencil, { size: 13 })),
                    React.createElement("button", { onClick: () => setConfirmDelete(e), style: iconBtn(theme) },
                        React.createElement(Trash2, { size: 13 }))))))));
        }),
        editing && (React.createElement(ModalShell, { onClose: () => setEditing(null), theme: theme },
            React.createElement("div", { style: { fontSize: 15, fontWeight: 800, color: theme.text, marginBottom: 16 } }, t.editEntry),
            React.createElement(EditAmount, { entry: editing, theme: theme, t: t, onCancel: () => setEditing(null), onSave: (amt) => { editEntry(editing.id, amt); setEditing(null); } }))),
        confirmDelete && (React.createElement(ModalShell, { onClose: () => setConfirmDelete(null), theme: theme },
            React.createElement("div", { style: { fontSize: 15, fontWeight: 700, color: theme.text, marginBottom: 20 } }, t.deleteConfirm),
            React.createElement("div", { style: { display: "flex", gap: 10 } },
                React.createElement("button", { onClick: () => setConfirmDelete(null), style: { flex: 1, padding: "13px", borderRadius: 14, border: `1px solid ${theme.border}`, background: "transparent", color: theme.text, fontWeight: 700, cursor: "pointer" } }, t.no),
                React.createElement("button", { onClick: () => { deleteEntry(confirmDelete.id); setConfirmDelete(null); }, style: { flex: 1, padding: "13px", borderRadius: 14, border: "none", background: "#E0554E", color: "#fff", fontWeight: 800, cursor: "pointer" } }, t.yes))))));
}
function EditAmount({ entry, theme, t, onCancel, onSave }) {
    const [val, setVal] = useState(String(entry.amount));
    return (React.createElement(React.Fragment, null,
        React.createElement("input", { value: val, onChange: (e) => setVal(e.target.value.replace(/[^0-9.]/g, "")), inputMode: "decimal", style: { ...inputStyle, background: theme.bg, color: theme.text, borderColor: theme.border, textAlign: "center", fontSize: 20, fontWeight: 800, marginBottom: 18 } }),
        React.createElement("div", { style: { display: "flex", gap: 10 } },
            React.createElement("button", { onClick: onCancel, style: { flex: 1, padding: "13px", borderRadius: 14, border: `1px solid ${theme.border}`, background: "transparent", color: theme.text, fontWeight: 700, cursor: "pointer" } }, t.cancel),
            React.createElement("button", { onClick: () => { const n = parseFloat(val); if (!isNaN(n) && n >= 0)
                    onSave(n); }, style: { flex: 1, padding: "13px", borderRadius: 14, border: "none", background: theme.primary, color: "#fff", fontWeight: 800, cursor: "pointer" } }, t.save))));
}
function CustomChallengePanel({ ctx }) {
    const { state, setState, t, theme, lang } = ctx;
    const [title, setTitle] = useState("");
    const [icon, setIcon] = useState("✨");
    const [category, setCategory] = useState("habits");
    const [saving, setSaving] = useState("");
    const [xp, setXp] = useState("20");
    function add() {
        if (!title || !saving)
            return;
        const c = { id: `custom${Date.now()}`, category, icon, saving: parseFloat(saving) || 0, xp: parseInt(xp) || 10, ar: { title, desc: "" }, en: { title, desc: "" } };
        setState((s) => ({ ...s, customChallenges: [...(s.customChallenges || []), c] }));
        setTitle("");
        setSaving("");
        setXp("20");
    }
    return (React.createElement("div", { style: { padding: "0 20px" } },
        React.createElement("div", { style: { background: theme.card, borderRadius: 18, padding: 16, border: `1px solid ${theme.border}`, marginBottom: 16 } },
            React.createElement("div", { style: { display: "flex", gap: 8, marginBottom: 10, flexWrap: "wrap" } }, ["✨", "💪", "📵", "🧘", "🚿", "🎁"].map((e) => (React.createElement("button", { key: e, onClick: () => setIcon(e), style: { width: 34, height: 34, borderRadius: 9, border: icon === e ? `2px solid ${theme.primary}` : `1px solid ${theme.border}`, background: theme.bg, fontSize: 16, cursor: "pointer" } }, e)))),
            React.createElement("input", { value: title, onChange: (e) => setTitle(e.target.value), placeholder: t.challengeName, style: { ...inputStyle, background: theme.bg, color: theme.text, borderColor: theme.border, marginBottom: 10 } }),
            React.createElement("select", { value: category, onChange: (e) => setCategory(e.target.value), style: { ...inputStyle, background: theme.bg, color: theme.text, borderColor: theme.border, marginBottom: 10 } }, CATS.map((c) => React.createElement("option", { key: c.id, value: c.id },
                c.icon,
                " ",
                t[c.ar]))),
            React.createElement("div", { style: { display: "flex", gap: 10, marginBottom: 12 } },
                React.createElement("input", { value: saving, onChange: (e) => setSaving(e.target.value.replace(/[^0-9.]/g, "")), placeholder: t.expectedSaving, inputMode: "decimal", style: { ...inputStyle, background: theme.bg, color: theme.text, borderColor: theme.border } }),
                React.createElement("input", { value: xp, onChange: (e) => setXp(e.target.value.replace(/[^0-9]/g, "")), placeholder: t.xpReward, inputMode: "numeric", style: { ...inputStyle, background: theme.bg, color: theme.text, borderColor: theme.border } })),
            React.createElement("button", { onClick: add, style: { width: "100%", padding: "13px", borderRadius: 14, border: "none", background: theme.primary, color: "#fff", fontWeight: 800, cursor: "pointer" } }, t.add)),
        React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: 8 } }, (state.customChallenges || []).map((c) => (React.createElement("div", { key: c.id, style: { background: theme.card, borderRadius: 14, padding: 12, border: `1px solid ${theme.border}`, display: "flex", alignItems: "center", gap: 10 } },
            React.createElement("div", { style: { fontSize: 18 } }, c.icon),
            React.createElement("div", { style: { flex: 1 } },
                React.createElement("div", { style: { fontSize: 13, fontWeight: 700, color: theme.text } }, c.ar.title),
                React.createElement("div", { style: { fontSize: 11, color: theme.sub } },
                    formatMoney(c.saving, state.currency, lang),
                    " \u00B7 +",
                    c.xp,
                    " XP"))))))));
}
/* ---------------------------------------------------------------------- */
/* Stats                                                                    */
/* ---------------------------------------------------------------------- */
function StatsScreen({ ctx }) {
    const { state, derived, t, theme, lang } = ctx;
    const [range, setRange] = useState(7);
    const chartData = useMemo(() => {
        const days = range === 180 ? 26 : range; // 6 months -> weekly buckets simplified to 26 pts
        const points = [];
        if (range === 180) {
            for (let w = 25; w >= 0; w--) {
                const start = daysAgo(w * 7 + 6), end = daysAgo(w * 7);
                const sum = state.history.filter((h) => h.date >= start && h.date <= end).reduce((s, h) => s + h.amount, 0);
                points.push(sum);
            }
        }
        else {
            for (let d = days - 1; d >= 0; d--) {
                const day = daysAgo(d);
                const sum = state.history.filter((h) => h.date === day).reduce((s, h) => s + h.amount, 0);
                points.push(sum);
            }
        }
        return points;
    }, [state.history, range]);
    const max = Math.max(1, ...chartData);
    const avgDaily = state.history.length ? (derived.totalSavings / Math.max(1, new Set(state.history.map((h) => h.date)).size)) : 0;
    const stats = [
        { icon: "💰", label: t.totalSavings, val: formatMoney(derived.totalSavings, state.currency, lang) },
        { icon: "📅", label: t.monthSaving, val: formatMoney(derived.monthSaving, state.currency, lang) },
        { icon: "🔥", label: t.currentStreak, val: derived.currentStreak },
        { icon: "🏆", label: t.bestStreak, val: derived.bestStreak },
        { icon: "⭐", label: t.totalXP, val: derived.totalXP },
        { icon: "🎯", label: t.completedChallenges, val: derived.completedCount },
    ];
    return (React.createElement("div", { className: "waf-fade" },
        React.createElement(Header, { title: `📊 ${t.stats}`, theme: theme }),
        React.createElement("div", { style: { padding: "0 20px" } },
            React.createElement("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 18 } }, stats.map((s, i) => (React.createElement("div", { key: i, style: { background: theme.card, borderRadius: 16, padding: 14, border: `1px solid ${theme.border}` } },
                React.createElement("div", { style: { fontSize: 20, marginBottom: 6 } }, s.icon),
                React.createElement("div", { style: { fontSize: 16, fontWeight: 800, color: theme.text } }, s.val),
                React.createElement("div", { style: { fontSize: 11, color: theme.sub, marginTop: 2 } }, s.label))))),
            React.createElement("div", { style: { background: theme.card, borderRadius: 18, padding: 16, border: `1px solid ${theme.border}`, marginBottom: 16 } },
                React.createElement("div", { style: { display: "flex", gap: 6, marginBottom: 14 } }, [[7, t.last7], [30, t.last30], [180, t.last6m]].map(([r, l]) => (React.createElement("button", { key: r, onClick: () => setRange(r), style: { padding: "6px 12px", borderRadius: 999, border: range === r ? "none" : `1px solid ${theme.border}`, background: range === r ? theme.primary : "transparent", color: range === r ? "#fff" : theme.text, fontSize: 11.5, fontWeight: 700, cursor: "pointer" } }, l)))),
                React.createElement("div", { style: { display: "flex", alignItems: "flex-end", gap: 3, height: 90 } }, chartData.map((v, i) => (React.createElement("div", { key: i, style: { flex: 1, height: `${Math.max(4, (v / max) * 100)}%`, background: theme.primary, borderRadius: 3, opacity: v === 0 ? 0.25 : 1 } }))))),
            React.createElement("div", { style: { background: theme.card, borderRadius: 18, padding: 16, border: `1px solid ${theme.border}`, marginBottom: 16 } },
                React.createElement("div", { style: { fontSize: 13, color: theme.sub, marginBottom: 4 } }, t.dailyAvg),
                React.createElement("div", { style: { fontSize: 20, fontWeight: 800, color: theme.text } }, formatMoney(avgDaily, state.currency, lang))),
            derived.topCategory && (React.createElement("div", { style: { background: theme.card, borderRadius: 18, padding: 16, border: `1px solid ${theme.border}` } },
                React.createElement("div", { style: { fontSize: 13, color: theme.sub, marginBottom: 8 } }, t.topCategory),
                React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 10 } },
                    React.createElement("div", { style: { fontSize: 24 } }, catIcon(derived.topCategory.id)),
                    React.createElement("div", null,
                        React.createElement("div", { style: { fontWeight: 800, fontSize: 14, color: theme.text } }, catLabel(derived.topCategory.id, t)),
                        React.createElement("div", { style: { fontSize: 12, color: theme.sub } }, formatMoney(derived.topCategory.v, state.currency, lang)))))))));
}
/* ---------------------------------------------------------------------- */
/* Achievements                                                            */
/* ---------------------------------------------------------------------- */
function AchievementsScreen({ ctx }) {
    const { state, t, theme } = ctx;
    return (React.createElement("div", { className: "waf-fade" },
        React.createElement(Header, { title: `🏆 ${t.achievements}`, theme: theme }),
        React.createElement("div", { style: { padding: "0 20px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 } }, ACHIEVEMENTS.map((a) => {
            const unlocked = state.unlockedAchievements.includes(a.id);
            return (React.createElement("div", { key: a.id, style: { background: theme.card, borderRadius: 18, padding: 16, border: `1px solid ${theme.border}`, textAlign: "center", opacity: unlocked ? 1 : 0.5 } },
                React.createElement("div", { style: { fontSize: 34, marginBottom: 8, filter: unlocked ? "none" : "grayscale(1)" } }, a.icon),
                React.createElement("div", { style: { fontSize: 13, fontWeight: 800, color: theme.text, marginBottom: 4 } }, t[a.nameKey]),
                React.createElement("div", { style: { fontSize: 10.5, color: theme.sub, lineHeight: 1.5 } }, t[a.descKey]),
                React.createElement("div", { style: { marginTop: 8, fontSize: 10, fontWeight: 700, color: unlocked ? theme.primary : theme.sub } }, unlocked ? t.unlocked : t.locked)));
        }))));
}
/* ---------------------------------------------------------------------- */
/* Profile                                                                  */
/* ---------------------------------------------------------------------- */
function ProfileScreen({ ctx }) {
    const { state, setState, derived, t, theme, lang, dark } = ctx;
    const [modal, setModal] = useState(null);
    const [manualForm, setManualForm] = useState(false);
    const rows = [
        { icon: Target, label: t.myGoals, action: () => { }, tabHint: true },
        { icon: Globe, label: t.language, right: lang === "ar" ? "العربية" : "English", action: () => setModal("lang") },
        { icon: Wallet, label: t.currency, right: state.currency, action: () => setModal("currency") },
        { icon: Bell, label: t.notifications, toggle: true },
        { icon: dark ? Sun : Moon, label: t.darkMode, darkToggle: true },
        { icon: Crown, label: t.premium, action: () => setModal("premium") },
        { icon: HelpCircle, label: t.help, action: () => setModal("help") },
        { icon: Star, label: t.rateApp, action: () => setModal("rate") },
        { icon: Share2, label: t.shareApp, action: () => setModal("share") },
        { icon: Shield, label: t.privacy, action: () => setModal("privacy") },
        { icon: FileText, label: t.terms, action: () => setModal("terms") },
    ];
    return (React.createElement("div", { className: "waf-fade" },
        React.createElement(Header, { title: `👤 ${t.profile}`, theme: theme }),
        React.createElement("div", { style: { padding: "0 20px" } },
            React.createElement("div", { style: { background: `linear-gradient(135deg, ${theme.primaryDark}, ${theme.primary})`, borderRadius: 22, padding: 22, color: "#fff", textAlign: "center", marginBottom: 18 } },
                React.createElement("div", { style: { width: 62, height: 62, borderRadius: 20, background: "rgba(255,255,255,0.18)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 26, fontWeight: 800, margin: "0 auto 10px" } }, (state.name || "W").charAt(0).toUpperCase()),
                React.createElement("div", { style: { fontSize: 17, fontWeight: 800 } }, state.name || t.welcome),
                React.createElement("div", { style: { fontSize: 12, opacity: 0.85, marginTop: 2 } },
                    t.level,
                    " ",
                    derived.level.level,
                    " \u00B7 ",
                    t[derived.level.key]),
                React.createElement("div", { style: { display: "flex", justifyContent: "center", gap: 20, marginTop: 16 } },
                    React.createElement("div", null,
                        React.createElement("div", { style: { fontWeight: 800, fontSize: 15 } }, formatMoney(derived.totalSavings, state.currency, lang)),
                        React.createElement("div", { style: { fontSize: 10, opacity: 0.8 } }, t.totalSaved)),
                    React.createElement("div", null,
                        React.createElement("div", { style: { fontWeight: 800, fontSize: 15 } },
                            derived.currentStreak,
                            " \uD83D\uDD25"),
                        React.createElement("div", { style: { fontSize: 10, opacity: 0.8 } }, t.streak)),
                    React.createElement("div", null,
                        React.createElement("div", { style: { fontWeight: 800, fontSize: 15 } }, derived.totalXP),
                        React.createElement("div", { style: { fontSize: 10, opacity: 0.8 } }, "XP")))),
            React.createElement("button", { onClick: () => setManualForm(true), style: { width: "100%", padding: "13px", borderRadius: 14, border: "none", background: theme.accent, color: "#3D2A05", fontWeight: 800, fontSize: 13.5, cursor: "pointer", marginBottom: 18, display: "flex", alignItems: "center", justifyContent: "center", gap: 6 } },
                React.createElement(Plus, { size: 16 }),
                " ",
                t.addManual),
            React.createElement("div", { style: { background: theme.card, borderRadius: 18, border: `1px solid ${theme.border}`, overflow: "hidden" } }, rows.map((r, i) => {
                const Icon = r.icon;
                return (React.createElement("div", { key: i, onClick: r.action, style: { display: "flex", alignItems: "center", gap: 12, padding: "14px 16px", borderBottom: i < rows.length - 1 ? `1px solid ${theme.border}` : "none", cursor: r.action ? "pointer" : "default" } },
                    React.createElement(Icon, { size: 18, color: theme.primary }),
                    React.createElement("div", { style: { flex: 1, fontSize: 13.5, fontWeight: 600, color: theme.text } }, r.label),
                    r.right && React.createElement("div", { style: { fontSize: 12, color: theme.sub } }, r.right),
                    r.toggle && React.createElement(Toggle, { checked: state.notifications, onChange: (v) => setState((s) => ({ ...s, notifications: v })), theme: theme }),
                    r.darkToggle && React.createElement(Toggle, { checked: dark, onChange: (v) => setState((s) => ({ ...s, theme: v ? "dark" : "light" })), theme: theme }),
                    !r.toggle && !r.darkToggle && r.action && (lang === "ar" ? React.createElement(ChevronLeft, { size: 16, color: theme.sub }) : React.createElement(ChevronRight, { size: 16, color: theme.sub }))));
            }))),
        modal === "lang" && (React.createElement(ModalShell, { onClose: () => setModal(null), theme: theme },
            React.createElement("div", { style: { fontSize: 15, fontWeight: 800, color: theme.text, marginBottom: 16 } }, t.language),
            [{ k: "ar", l: "🇸🇦 العربية" }, { k: "en", l: "🇬🇧 English" }].map((o) => (React.createElement("button", { key: o.k, onClick: () => { setState((s) => ({ ...s, language: o.k })); setModal(null); }, style: { width: "100%", padding: "13px", borderRadius: 14, border: lang === o.k ? `2px solid ${theme.primary}` : `1px solid ${theme.border}`, background: "transparent", color: theme.text, fontWeight: 700, marginBottom: 8, cursor: "pointer" } }, o.l))))),
        modal === "currency" && (React.createElement(ModalShell, { onClose: () => setModal(null), theme: theme },
            React.createElement("div", { style: { fontSize: 15, fontWeight: 800, color: theme.text, marginBottom: 16 } }, t.currency),
            React.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center" } }, CURRENCIES.map((c) => (React.createElement("button", { key: c.code, onClick: () => { setState((s) => ({ ...s, currency: c.code })); setModal(null); }, style: pillStyle2(state.currency === c.code, theme) },
                c.symbol,
                " ",
                c.code)))))),
        modal === "premium" && (React.createElement(ModalShell, { onClose: () => setModal(null), theme: theme },
            React.createElement("div", { style: { fontSize: 30 } }, "\uD83D\uDC51"),
            React.createElement("div", { style: { fontSize: 17, fontWeight: 800, color: theme.text, margin: "8px 0 6px" } }, t.premium),
            React.createElement("div", { style: { fontSize: 13, color: theme.sub, lineHeight: 1.7, marginBottom: 16 } }, t.premiumBody),
            React.createElement("div", { style: { textAlign: lang === "ar" ? "right" : "left", background: theme.cardAlt, borderRadius: 14, padding: 14, marginBottom: 10 } },
                React.createElement("div", { style: { fontSize: 11.5, fontWeight: 800, color: theme.primary, marginBottom: 4 } }, t.freeFeatures),
                React.createElement("div", { style: { fontSize: 12, color: theme.sub, lineHeight: 1.7 } }, t.freeList)),
            React.createElement("div", { style: { textAlign: lang === "ar" ? "right" : "left", background: theme.cardAlt, borderRadius: 14, padding: 14, marginBottom: 18 } },
                React.createElement("div", { style: { fontSize: 11.5, fontWeight: 800, color: theme.accent, marginBottom: 4 } }, t.premiumFeatures),
                React.createElement("div", { style: { fontSize: 12, color: theme.sub, lineHeight: 1.7 } }, t.premiumList)),
            React.createElement("button", { disabled: true, style: { width: "100%", padding: "13px", borderRadius: 14, border: "none", background: theme.border, color: theme.sub, fontWeight: 800, cursor: "not-allowed" } }, t.comingSoon))),
        (modal === "help" || modal === "rate" || modal === "share") && (React.createElement(ModalShell, { onClose: () => setModal(null), theme: theme },
            React.createElement("div", { style: { fontSize: 30 } }, modal === "help" ? "❓" : modal === "rate" ? "⭐" : "📤"),
            React.createElement("div", { style: { fontSize: 13, color: theme.sub, marginTop: 10 } }, t.comingSoon))),
        modal === "privacy" && (React.createElement(ModalShell, { onClose: () => setModal(null), theme: theme },
            React.createElement("div", { style: { fontSize: 16, fontWeight: 800, color: theme.text, marginBottom: 10 } },
                "\uD83D\uDD12 ",
                t.privacy),
            React.createElement("div", { style: { fontSize: 13, color: theme.sub, lineHeight: 1.8 } }, t.privacyBody))),
        modal === "terms" && (React.createElement(ModalShell, { onClose: () => setModal(null), theme: theme },
            React.createElement("div", { style: { fontSize: 16, fontWeight: 800, color: theme.text, marginBottom: 10 } },
                "\uD83D\uDCC4 ",
                t.terms),
            React.createElement("div", { style: { fontSize: 13, color: theme.sub, lineHeight: 1.8 } }, t.termsBody))),
        manualForm && React.createElement(ManualSavingModal, { ctx: ctx, onClose: () => setManualForm(false) })));
}
function pillStyle2(active, theme) {
    return { padding: "10px 14px", borderRadius: 999, border: active ? `1.5px solid ${theme.primary}` : `1.5px solid ${theme.border}`, background: active ? theme.primary : "transparent", color: active ? "#fff" : theme.text, fontSize: 13, fontWeight: 700, cursor: "pointer" };
}
function Toggle({ checked, onChange, theme }) {
    return (React.createElement("button", { onClick: () => onChange(!checked), style: { width: 42, height: 24, borderRadius: 999, border: "none", background: checked ? theme.primary : theme.border, position: "relative", cursor: "pointer", transition: "background .2s" } },
        React.createElement("div", { style: { position: "absolute", top: 3, left: checked ? 21 : 3, width: 18, height: 18, borderRadius: "50%", background: "#fff", transition: "left .2s" } })));
}
function ManualSavingModal({ ctx, onClose }) {
    const { t, theme, addManualSaving } = ctx;
    const [note, setNote] = useState("");
    const [amount, setAmount] = useState("");
    const [category, setCategory] = useState("habits");
    return (React.createElement(ModalShell, { onClose: onClose, theme: theme },
        React.createElement("div", { style: { fontSize: 16, fontWeight: 800, color: theme.text, marginBottom: 16 } }, t.manualPrompt),
        React.createElement("input", { value: note, onChange: (e) => setNote(e.target.value), placeholder: t.manualPh, style: { ...inputStyle, background: theme.bg, color: theme.text, borderColor: theme.border, marginBottom: 10 } }),
        React.createElement("input", { value: amount, onChange: (e) => setAmount(e.target.value.replace(/[^0-9.]/g, "")), placeholder: t.amount, inputMode: "decimal", style: { ...inputStyle, background: theme.bg, color: theme.text, borderColor: theme.border, marginBottom: 10 } }),
        React.createElement("select", { value: category, onChange: (e) => setCategory(e.target.value), style: { ...inputStyle, background: theme.bg, color: theme.text, borderColor: theme.border, marginBottom: 16 } }, CATS.map((c) => React.createElement("option", { key: c.id, value: c.id },
            c.icon,
            " ",
            t[c.ar]))),
        React.createElement("div", { style: { display: "flex", gap: 10 } },
            React.createElement("button", { onClick: onClose, style: { flex: 1, padding: "13px", borderRadius: 14, border: `1px solid ${theme.border}`, background: "transparent", color: theme.text, fontWeight: 700, cursor: "pointer" } }, t.cancel),
            React.createElement("button", { onClick: () => { const n = parseFloat(amount); if (isNaN(n) || n <= 0)
                    return; addManualSaving(n, category, note); onClose(); }, style: { flex: 1, padding: "13px", borderRadius: 14, border: "none", background: theme.primary, color: "#fff", fontWeight: 800, cursor: "pointer" } }, t.add))));
}

Preact.render(React.createElement(WafferhaApp,null),document.getElementById("root"));
